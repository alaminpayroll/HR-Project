import React, { useState, useEffect } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import {
  auth,
  loginWithGoogle,
  logoutUser,
  testConnection,
} from './firebase';
import {
  subscribeEmployees,
  saveEmployee,
  deleteEmployeeRecord,
  subscribeEmployeeLeaves,
  saveEmployeeLeave,
  bulkSaveEmployeeLeaves,
  deleteEmployeeLeave,
  getCompanySettings,
  saveCompanySettings,
  generateCleanId,
} from './services/dbService';
import type {
  Employee,
  CompanySetting,
  EmployeeLeave,
} from './types';
import { Navbar } from './components/Navbar';
import { EmployeePortalView } from './components/EmployeePortalView';
import { EmployeeModal } from './components/EmployeeModal';
import { MasterLoginModal } from './components/MasterLoginModal';
import { ShareModal } from './components/ShareModal';
import { downloadLeaveExcelTemplate } from './utils/excelUtils';
import { CompanyLogo } from './components/CompanyLogo';

const INITIAL_DEMO_EMPLOYEES: Omit<Employee, 'id' | 'userId'>[] = [
  {
    employeeCode: 'EMP-001',
    name: 'মোঃ আল-আমিন',
    phone: '01711223344',
    designation: 'ম্যানেজার (এইচআর ও এডমিন)',
    department: 'এইচআর ও কমপ্লায়েন্স',
    monthlySalary: 38000,
    salaryType: 'monthly',
    joiningDate: '2023-01-15',
    status: 'active',
    paymentMethod: 'bank',
    accountDetails: 'ডাচ-বাংলা ব্যাংক: 151.101.98765',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    employeeCode: 'EMP-002',
    name: 'মোঃ শাকিল আহমেদ',
    phone: '01822334455',
    designation: 'কোয়ালিটি ইনচার্জ',
    department: 'কোয়ালিটি কন্ট্রোল (QC)',
    monthlySalary: 28000,
    salaryType: 'monthly',
    joiningDate: '2023-08-01',
    status: 'active',
    paymentMethod: 'bKash',
    accountDetails: 'বিকাশ পার্সোনাল: 01822334455',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    employeeCode: 'EMP-003',
    name: 'মোছাঃ ফাতেমা আক্তার',
    phone: '01933445566',
    designation: 'সিনিয়র অপারেটর',
    department: 'সুইং সেকশন',
    monthlySalary: 22000,
    salaryType: 'monthly',
    joiningDate: '2024-02-10',
    status: 'active',
    paymentMethod: 'cash',
    accountDetails: 'নগদ ক্যাশ গ্রহণ',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    employeeCode: 'EMP-004',
    name: 'মোঃ রফিকুল ইসলাম',
    phone: '01755667788',
    designation: 'কাটিং সুপারভাইজার',
    department: 'কাটিং সেকশন',
    monthlySalary: 26000,
    salaryType: 'monthly',
    joiningDate: '2023-05-20',
    status: 'active',
    paymentMethod: 'bank',
    accountDetails: 'ইসলামী ব্যাংক: 2050.123.456',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [language, setLanguage] = useState<'bn' | 'en'>('bn');

  // Master User Authentication State
  // Master is true if user is logged in as alaminpayroll@gmail.com OR entered Master Passcode
  const [isMasterPasscodeUnlocked, setIsMasterPasscodeUnlocked] = useState<boolean>(() => {
    return localStorage.getItem('progress_master_mode') === 'true';
  });
  const [isMasterLoginModalOpen, setIsMasterLoginModalOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);

  // Application Data States
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [leaves, setLeaves] = useState<EmployeeLeave[]>([]);
  const [settings, setSettings] = useState<CompanySetting>({
    id: 'default',
    userId: 'default',
    companyName: 'Progress Apparels Bangladesh Ltd.',
    phone: '01711223344',
    currency: '৳',
    workingDaysPerMonth: 26,
    overtimeRatePerHour: 120,
    language: 'bn',
    updatedAt: new Date().toISOString(),
  });

  // Modal states
  const [isEmployeeModalOpen, setIsEmployeeModalOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);

  // Determine if current user is Master User
  const isMasterUser = Boolean(
    isMasterPasscodeUnlocked ||
    (user && (user.email?.toLowerCase().includes('alamin') || user.email?.toLowerCase() === 'alaminpayroll@gmail.com'))
  );

  const effectiveUserId = user?.uid || 'progress-master-shared';
  const isBn = language === 'bn';

  // 1. Initial boot test connection as required by Firestore skill
  useEffect(() => {
    testConnection().catch((err) => console.log('Connection test: ', err));
  }, []);

  // 2. Auth State Observer
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setAuthLoading(false);
    });
    return () => unsubscribe();
  }, []);

  // 3. Realtime Firestore Subscriptions for Employees and Leaves
  useEffect(() => {
    // Both viewers and master subscribe to the real-time company Firestore data
    const unsubEmployees = subscribeEmployees(effectiveUserId, (list) => {
      if (list.length === 0) {
        seedInitialFirestoreData(effectiveUserId);
      } else {
        setEmployees(list);
      }
    });

    const unsubLeaves = subscribeEmployeeLeaves(effectiveUserId, (list) => {
      setLeaves(list);
    });

    getCompanySettings(effectiveUserId).then((st) => {
      if (st) {
        setSettings(st);
      } else {
        const initialSetting: CompanySetting = {
          id: 'default',
          userId: effectiveUserId,
          companyName: 'Progress Apparels Bangladesh Ltd.',
          ownerEmail: 'alaminpayroll@gmail.com',
          phone: '',
          currency: '৳',
          workingDaysPerMonth: 26,
          overtimeRatePerHour: 120,
          language: 'bn',
          updatedAt: new Date().toISOString(),
        };
        saveCompanySettings(initialSetting).catch(console.error);
        setSettings(initialSetting);
      }
    });

    return () => {
      unsubEmployees();
      unsubLeaves();
    };
  }, []);

  // Seed demo data on initial database setup
  const seedInitialFirestoreData = async (targetUserId: string) => {
    const initialList: Employee[] = INITIAL_DEMO_EMPLOYEES.map((d, index) => ({
      ...d,
      id: generateCleanId(`emp-${index + 1}`),
      userId: targetUserId,
    }));

    for (const emp of initialList) {
      await saveEmployee(emp);
    }

    const initialLeaveList: EmployeeLeave[] = initialList.map((emp, index) => {
      if (index === 0) {
        // Exact values matching user's specification for Al-Amin
        return {
          id: generateCleanId(`leave-${emp.id}`),
          userId: targetUserId,
          employeeId: emp.id,
          employeeCode: emp.employeeCode || 'EMP-001',
          employeeName: emp.name,
          department: emp.department,
          designation: emp.designation,
          doj: emp.joiningDate || '2023-01-15',
          year: new Date().getFullYear(),
          casualAllocated: 10,
          casualAvailed: 5,
          casualBalance: 5,
          sickAllocated: 14,
          sickAvailed: 3,
          sickBalance: 11,
          earnAllocated: 8,
          earnAvailed: 1,
          earnBalance: 7,
          specialAllocated: 0,
          specialAvailed: 0,
          specialBalance: 0,
          lwpAvailed: 0,
          updatedAt: new Date().toISOString(),
        };
      }
      return {
        id: generateCleanId(`leave-${emp.id}`),
        userId: targetUserId,
        employeeId: emp.id,
        employeeCode: emp.employeeCode || `EMP-00${index + 1}`,
        employeeName: emp.name,
        department: emp.department,
        designation: emp.designation,
        doj: emp.joiningDate || '2023-06-01',
        year: new Date().getFullYear(),
        casualAllocated: 10,
        casualAvailed: 2 + index,
        casualBalance: 10 - (2 + index),
        sickAllocated: 14,
        sickAvailed: 1 + index,
        sickBalance: 14 - (1 + index),
        earnAllocated: 8,
        earnAvailed: index,
        earnBalance: 8 - index,
        specialAllocated: 0,
        specialAvailed: 0,
        specialBalance: 0,
        lwpAvailed: 0,
        updatedAt: new Date().toISOString(),
      };
    });

    await bulkSaveEmployeeLeaves(initialLeaveList);
    setEmployees(initialList);
    setLeaves(initialLeaveList);
  };

  // Handlers for Firestore CRUD (Only executed by Master User)
  const handleSaveEmployee = async (employee: Employee) => {
    await saveEmployee({ ...employee, userId: effectiveUserId });
  };

  const handleDeleteEmployee = async (employeeId: string, leaveId?: string) => {
    await deleteEmployeeRecord(employeeId);
    if (leaveId) {
      await deleteEmployeeLeave(leaveId);
    }
    // Also remove from local state immediately for smooth UI
    setEmployees((prev) => prev.filter((e) => e.id !== employeeId));
    setLeaves((prev) => prev.filter((l) => l.employeeId !== employeeId && l.id !== leaveId));
  };

  const handleSaveLeave = async (leave: EmployeeLeave) => {
    await saveEmployeeLeave({ ...leave, userId: effectiveUserId });
  };

  const handleBulkSaveLeaves = async (newLeaves: EmployeeLeave[]) => {
    const formatted = newLeaves.map((l) => ({ ...l, userId: effectiveUserId }));
    await bulkSaveEmployeeLeaves(formatted);

    // Also auto-create or update any new employees found in the Excel upload
    for (const l of newLeaves) {
      const exists = employees.some(
        (e) =>
          (l.employeeCode && e.employeeCode.toUpperCase() === l.employeeCode.toUpperCase()) ||
          e.name.toLowerCase() === l.employeeName.toLowerCase()
      );
      if (!exists) {
        const newEmp: Employee = {
          id: l.employeeId || generateCleanId('emp'),
          userId: effectiveUserId,
          employeeCode: l.employeeCode || `EMP-${Math.floor(100 + Math.random() * 900)}`,
          name: l.employeeName,
          phone: '',
          designation: l.designation || 'Staff',
          department: l.department || 'General',
          monthlySalary: 25000,
          salaryType: 'monthly',
          joiningDate: l.doj || new Date().toISOString().split('T')[0],
          status: 'active',
          paymentMethod: 'cash',
          accountDetails: '',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        await saveEmployee(newEmp);
      }
    }
  };

  const handleGoogleLogin = async () => {
    try {
      const loggedUser = await loginWithGoogle();
      if (loggedUser) {
        setUser(loggedUser);
        setIsMasterPasscodeUnlocked(true);
        localStorage.setItem('progress_master_mode', 'true');
      }
    } catch (err) {
      console.error('Login failed:', err);
      throw err;
    }
  };

  const handleLogout = async () => {
    try {
      await logoutUser();
      setUser(null);
      setIsMasterPasscodeUnlocked(false);
      localStorage.removeItem('progress_master_mode');
    } catch (err) {
      console.error('Logout failed:', err);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col selection:bg-rose-600 selection:text-white print:bg-white print:min-h-0 print:m-0 print:p-0">
      {/* Singular Navigation Header (Zero Duplication) */}
      <Navbar
        user={user}
        isMasterUser={isMasterUser}
        onLogout={handleLogout}
        onOpenMasterLogin={() => setIsMasterLoginModalOpen(true)}
        language={language}
        setLanguage={setLanguage}
        onOpenUploadModal={() => {
          // Triggers bulk upload in portal
          const uploadBtn = document.querySelector<HTMLButtonElement>(
            '#printable-employee-portal ~ div button, main button:has(svg)'
          );
          uploadBtn?.click();
        }}
        onOpenEmployeeModal={() => {
          setEditingEmployee(null);
          setIsEmployeeModalOpen(true);
        }}
        onDownloadTemplate={() => downloadLeaveExcelTemplate(employees)}
        onPrint={() => window.print()}
        onOpenShareModal={() => setIsShareModalOpen(true)}
      />

      {/* Main Single Dedicated View: Employee Leave Portal */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 print:p-0 print:m-0 print:max-w-none">
        <EmployeePortalView
          employees={employees}
          leaves={leaves}
          settings={settings}
          userId={effectiveUserId}
          isBn={isBn}
          isMasterUser={isMasterUser}
          onSaveLeave={handleSaveLeave}
          onBulkSaveLeaves={handleBulkSaveLeaves}
          onOpenEmployeeModal={() => {
            setEditingEmployee(null);
            setIsEmployeeModalOpen(true);
          }}
          onEditEmployee={(emp) => {
            setEditingEmployee(emp);
            setIsEmployeeModalOpen(true);
          }}
          onDeleteEmployee={handleDeleteEmployee}
          onOpenMasterLogin={() => setIsMasterLoginModalOpen(true)}
          onOpenShareModal={() => setIsShareModalOpen(true)}
        />
      </main>

      {/* Footer (Singular & Clean) */}
      <footer className="bg-white border-t border-slate-200 py-4 text-center text-xs text-slate-500 print:hidden">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row justify-between items-center gap-2">
          <div className="flex items-center gap-2">
            <CompanyLogo size={22} className="w-5 h-5 shrink-0" />
            <span className="font-bold text-slate-800">
              Progress Apparels Bangladesh Ltd.
            </span>
            <span className="text-slate-300">•</span>
            <span>
              {isBn
                ? 'Google Firebase Firestore ক্লাউড ব্যাকএন্ড দ্বারা স্থায়ীভাবে সংরক্ষিত'
                : 'Backed by Google Firebase Firestore Cloud Persistence'}
            </span>
          </div>
          <div className="flex items-center gap-2 font-mono text-[11px] text-slate-400">
            <span>Report by: AL-AMIN (Asst. Manager-HR)</span>
            <span>•</span>
            <span className="text-emerald-600 font-semibold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
              Cloud Synced
            </span>
          </div>
        </div>
      </footer>

      {/* Employee Modal (For Adding & Modifying) */}
      {isEmployeeModalOpen && (
        <EmployeeModal
          employee={editingEmployee}
          userId={effectiveUserId}
          onSave={handleSaveEmployee}
          onClose={() => {
            setIsEmployeeModalOpen(false);
            setEditingEmployee(null);
          }}
        />
      )}

      {/* Master Login Modal (For authenticating Master User) */}
      <MasterLoginModal
        isOpen={isMasterLoginModalOpen}
        onClose={() => setIsMasterLoginModalOpen(false)}
        onGoogleLogin={handleGoogleLogin}
        onPasscodeSuccess={() => {
          setIsMasterPasscodeUnlocked(true);
          localStorage.setItem('progress_master_mode', 'true');
        }}
        isBn={isBn}
      />

      {/* Share Modal for Public Access */}
      <ShareModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
        isBn={isBn}
      />
    </div>
  );
}
