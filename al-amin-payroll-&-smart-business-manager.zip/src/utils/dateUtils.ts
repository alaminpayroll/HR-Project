export function calculateServiceLength(
  dojStr: string,
  isBn = true
): { years: number; months: number; days: number; text: string } {
  if (!dojStr) {
    return {
      years: 0,
      months: 0,
      days: 0,
      text: isBn ? 'তথ্য পাওয়া যায়নি' : 'N/A',
    };
  }

  const startDate = new Date(dojStr);
  const endDate = new Date();

  if (isNaN(startDate.getTime()) || startDate > endDate) {
    return {
      years: 0,
      months: 0,
      days: 0,
      text: isBn ? 'নতুন যোগ দিয়েছেন' : 'Just Joined',
    };
  }

  let years = endDate.getFullYear() - startDate.getFullYear();
  let months = endDate.getMonth() - startDate.getMonth();
  let days = endDate.getDate() - startDate.getDate();

  if (days < 0) {
    months -= 1;
    // Days in previous month
    const prevMonthLastDay = new Date(
      endDate.getFullYear(),
      endDate.getMonth(),
      0
    ).getDate();
    days += prevMonthLastDay;
  }

  if (months < 0) {
    years -= 1;
    months += 12;
  }

  const banglaDigits: Record<string, string> = {
    '0': '০',
    '1': '১',
    '2': '২',
    '3': '৩',
    '4': '৪',
    '5': '৫',
    '6': '৬',
    '7': '৭',
    '8': '৮',
    '9': '৯',
  };

  const toBn = (n: number) =>
    n.toString().replace(/\d/g, (d) => banglaDigits[d] || d);

  let text = '';
  if (isBn) {
    const parts: string[] = [];
    if (years > 0) parts.push(`${toBn(years)} বছর`);
    if (months > 0) parts.push(`${toBn(months)} মাস`);
    if (days > 0 || parts.length === 0) parts.push(`${toBn(days)} দিন`);
    text = parts.join(' ');
  } else {
    const parts: string[] = [];
    if (years > 0) parts.push(`${years} ${years === 1 ? 'Year' : 'Years'}`);
    if (months > 0) parts.push(`${months} ${months === 1 ? 'Month' : 'Months'}`);
    if (days > 0 || parts.length === 0)
      parts.push(`${days} ${days === 1 ? 'Day' : 'Days'}`);
    text = parts.join(' ');
  }

  return { years, months, days, text };
}
