import * as XLSX from 'xlsx';
import type { Employee, EmployeeLeave } from '../types';
import { generateCleanId } from '../services/dbService';

export function downloadLeaveExcelTemplate(employees: Employee[]) {
  const sampleData =
    employees.length > 0
      ? employees.map((emp, index) => ({
          'Employee ID': emp.employeeCode || `EMP-${(index + 1).toString().padStart(3, '0')}`,
          'Employee Name': emp.name,
          'Designation': emp.designation,
          'Department': emp.department,
          'Date of Joining (DOJ)': emp.joiningDate || '2024-01-01',
          'CL Allocated': 10,
          'CL Availed': 5,
          'SL Allocated': 14,
          'SL Availed': 3,
          'EL Allocated': 8,
          'EL Availed': 1,
          'Special Allocated': 0,
          'Special Availed': 0,
          'LWP Availed': 0,
        }))
      : [
          {
            'Employee ID': 'EMP-001',
            'Employee Name': 'মোঃ আল-আমিন',
            'Designation': 'ম্যানেজার',
            'Department': 'অপারেশন',
            'Date of Joining (DOJ)': '2023-01-15',
            'CL Allocated': 10,
            'CL Availed': 5,
            'SL Allocated': 14,
            'SL Availed': 3,
            'EL Allocated': 8,
            'EL Availed': 1,
            'Special Allocated': 0,
            'Special Availed': 0,
            'LWP Availed': 0,
          },
          {
            'Employee ID': 'EMP-002',
            'Employee Name': 'শাকিল আহমেদ',
            'Designation': 'সুপারভাইজার',
            'Department': 'প্রোডাকশন',
            'Date of Joining (DOJ)': '2023-06-01',
            'CL Allocated': 10,
            'CL Availed': 4,
            'SL Allocated': 14,
            'SL Availed': 2,
            'EL Allocated': 8,
            'EL Availed': 0,
            'Special Allocated': 0,
            'Special Availed': 0,
            'LWP Availed': 0,
          },
        ];

  const worksheet = XLSX.utils.json_to_sheet(sampleData);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Employee Leaves');

  // Set column widths
  worksheet['!cols'] = [
    { wch: 15 }, // ID
    { wch: 22 }, // Name
    { wch: 18 }, // Desig
    { wch: 16 }, // Dept
    { wch: 20 }, // DOJ
    { wch: 14 }, // CL Alloc
    { wch: 12 }, // CL Avail
    { wch: 14 }, // SL Alloc
    { wch: 12 }, // SL Avail
    { wch: 14 }, // EL Alloc
    { wch: 12 }, // EL Avail
    { wch: 16 }, // Special Alloc
    { wch: 14 }, // Special Avail
    { wch: 14 }, // LWP
  ];

  XLSX.writeFile(workbook, `employee_leave_template_${new Date().toISOString().split('T')[0]}.xlsx`);
}

export async function parseLeaveExcelFile(
  file: File,
  userId: string,
  employees: Employee[]
): Promise<EmployeeLeave[]> {
  const arrayBuffer = await file.arrayBuffer();
  const workbook = XLSX.read(arrayBuffer, { type: 'array' });
  const sheetName = workbook.SheetNames[0];
  const worksheet = workbook.Sheets[sheetName];
  const rawRows: Record<string, any>[] = XLSX.utils.sheet_to_json(worksheet);

  const empMapByCode = new Map<string, Employee>();
  const empMapByName = new Map<string, Employee>();
  employees.forEach((emp) => {
    if (emp.employeeCode) empMapByCode.set(emp.employeeCode.trim().toUpperCase(), emp);
    empMapByName.set(emp.name.trim().toLowerCase(), emp);
  });

  const parsedLeaves: EmployeeLeave[] = [];

  for (const row of rawRows) {
    const rawId = String(row['Employee ID'] || row['ID'] || row['EmployeeID'] || '').trim();
    const rawName = String(row['Employee Name'] || row['Name'] || '').trim();
    if (!rawId && !rawName) continue;

    const matchedEmp =
      (rawId ? empMapByCode.get(rawId.toUpperCase()) : null) ||
      (rawName ? empMapByName.get(rawName.toLowerCase()) : null);

    const clAlloc = Number(row['CL Allocated'] ?? row['CL Allocation'] ?? 10) || 0;
    const clAvail = Number(row['CL Availed'] ?? row['CL Taken'] ?? 0) || 0;

    const slAlloc = Number(row['SL Allocated'] ?? row['SL Allocation'] ?? 14) || 0;
    const slAvail = Number(row['SL Availed'] ?? row['SL Taken'] ?? 0) || 0;

    const elAlloc = Number(row['EL Allocated'] ?? row['EL Allocation'] ?? 8) || 0;
    const elAvail = Number(row['EL Availed'] ?? row['EL Taken'] ?? 0) || 0;

    const spAlloc = Number(row['Special Allocated'] ?? row['Special Leave Allocated'] ?? 0) || 0;
    const spAvail = Number(row['Special Availed'] ?? row['Special Leave Availed'] ?? 0) || 0;

    const lwp = Number(row['LWP Availed'] ?? row['Leave without Pay'] ?? row['LWP'] ?? 0) || 0;

    const doj =
      String(
        row['Date of Joining (DOJ)'] ||
          row['DOJ'] ||
          row['Joining Date'] ||
          matchedEmp?.joiningDate ||
          ''
      ).trim() || new Date().toISOString().split('T')[0];

    const leaveObj: EmployeeLeave = {
      id: generateCleanId(`leave-${rawId || 'row'}`),
      userId,
      employeeId: matchedEmp?.id || generateCleanId('emp-ref'),
      employeeCode: rawId || matchedEmp?.employeeCode || `EMP-${parsedLeaves.length + 1}`,
      employeeName: rawName || matchedEmp?.name || 'Employee',
      department: String(row['Department'] || matchedEmp?.department || 'General'),
      designation: String(row['Designation'] || matchedEmp?.designation || 'Staff'),
      doj,
      year: new Date().getFullYear(),
      casualAllocated: clAlloc,
      casualAvailed: clAvail,
      casualBalance: Math.max(0, clAlloc - clAvail),
      sickAllocated: slAlloc,
      sickAvailed: slAvail,
      sickBalance: Math.max(0, slAlloc - slAvail),
      earnAllocated: elAlloc,
      earnAvailed: elAvail,
      earnBalance: Math.max(0, elAlloc - elAvail),
      specialAllocated: spAlloc,
      specialAvailed: spAvail,
      specialBalance: 0,
      lwpAvailed: lwp,
      updatedAt: new Date().toISOString(),
    };

    parsedLeaves.push(leaveObj);
  }

  return parsedLeaves;
}
