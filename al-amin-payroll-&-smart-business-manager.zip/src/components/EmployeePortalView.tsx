import React, { useState, useMemo, useRef } from 'react';
import {
  Upload,
  Download,
  Calendar,
  Briefcase,
  Building,
  Clock,
  Printer,
  FileSpreadsheet,
  CheckCircle2,
  AlertCircle,
  Eye,
  Info,
  Edit3,
  Save,
  X,
  Search,
  Trash2,
  UserPlus,
  ShieldCheck,
  UserCheck,
  Share2,
} from 'lucide-react';
import type { Employee, EmployeeLeave, CompanySetting } from '../types';
import { calculateServiceLength } from '../utils/dateUtils';
import { downloadLeaveExcelTemplate, parseLeaveExcelFile } from '../utils/excelUtils';
import { CompanyLogo } from './CompanyLogo';

interface EmployeePortalViewProps {
  employees: Employee[];
  leaves: EmployeeLeave[];
  settings: CompanySetting;
  userId: string;
  isBn: boolean;
  isMasterUser: boolean;
  onSaveLeave: (leave: EmployeeLeave) => Promise<void>;
  onBulkSaveLeaves: (leaves: EmployeeLeave[]) => Promise<void>;
  onOpenEmployeeModal?: () => void;
  onEditEmployee?: (employee: Employee) => void;
  onDeleteEmployee?: (employeeId: string, leaveId?: string) => Promise<void>;
  onOpenMasterLogin?: () => void;
  onOpenShareModal?: () => void;
}

export const EmployeePortalView: React.FC<EmployeePortalViewProps> = ({
  employees,
  leaves,
  userId,
  isBn,
  isMasterUser,
  onSaveLeave,
  onBulkSaveLeaves,
  onOpenEmployeeModal,
  onEditEmployee,
  onDeleteEmployee,
  onOpenMasterLogin,
  onOpenShareModal,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedEmpId, setSelectedEmpId] = useState<string>(
    employees[0]?.id || ''
  );
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadSuccessMsg, setUploadSuccessMsg] = useState('');
  const [uploadErrorMsg, setUploadErrorMsg] = useState('');
  const [parsedPreviewList, setParsedPreviewList] = useState<EmployeeLeave[]>([]);
  const [isEditingLeaves, setIsEditingLeaves] = useState(false);
  const [editingLeaveData, setEditingLeaveData] = useState<Partial<EmployeeLeave>>({});
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Map employee ID and Code to their leave record
  const leaveMap = useMemo(() => {
    const map = new Map<string, EmployeeLeave>();
    leaves.forEach((l) => {
      if (l.employeeId) map.set(l.employeeId, l);
      if (l.employeeCode) map.set(l.employeeCode.toUpperCase().trim(), l);
    });
    return map;
  }, [leaves]);

  // Selected Employee object
  const selectedEmployee = useMemo(() => {
    if (selectedEmpId) {
      const byId = employees.find((e) => e.id === selectedEmpId);
      if (byId) return byId;
      const byCode = employees.find((e) => e.employeeCode?.toUpperCase() === selectedEmpId.toUpperCase());
      if (byCode) return byCode;
    }
    return employees[0] || null;
  }, [employees, selectedEmpId]);

  // Current leave record for selected employee
  const currentLeave: EmployeeLeave = useMemo(() => {
    if (!selectedEmployee) {
      return {
        id: 'default',
        userId,
        employeeId: '',
        employeeCode: 'EMP-001',
        employeeName: 'N/A',
        department: 'N/A',
        designation: 'N/A',
        doj: '2023-01-15',
        year: new Date().getFullYear(),
        casualAllocated: 10,
        casualAvailed: 5,
        casualBalance: 5,
        sickAllocated: 14,
        sickAvailed: 3,
        sickBalance: 11,
        earnAllocated: 8,
        earnAvailed: 1,
        earnBalance: 7,
        specialAllocated: 0,
        specialAvailed: 0,
        specialBalance: 0,
        lwpAvailed: 0,
        updatedAt: new Date().toISOString(),
      };
    }

    const found =
      leaveMap.get(selectedEmployee.id) ||
      (selectedEmployee.employeeCode ? leaveMap.get(selectedEmployee.employeeCode.toUpperCase().trim()) : null);

    if (found) return found;

    return {
      id: `leave-${selectedEmployee.id}`,
      userId,
      employeeId: selectedEmployee.id,
      employeeCode: selectedEmployee.employeeCode || `EMP-${selectedEmployee.id.slice(0, 4)}`,
      employeeName: selectedEmployee.name,
      department: selectedEmployee.department,
      designation: selectedEmployee.designation,
      doj: selectedEmployee.joiningDate || '2023-01-15',
      year: new Date().getFullYear(),
      casualAllocated: 10,
      casualAvailed: 0,
      casualBalance: 10,
      sickAllocated: 14,
      sickAvailed: 0,
      sickBalance: 14,
      earnAllocated: 8,
      earnAvailed: 0,
      earnBalance: 8,
      specialAllocated: 0,
      specialAvailed: 0,
      specialBalance: 0,
      lwpAvailed: 0,
      updatedAt: new Date().toISOString(),
    };
  }, [selectedEmployee, leaveMap, userId]);

  // Calculate Service Length
  const serviceLength = useMemo(() => {
    const doj = selectedEmployee?.joiningDate || currentLeave.doj || '';
    return calculateServiceLength(doj, isBn);
  }, [selectedEmployee, currentLeave, isBn]);

  // Filtered employees for search
  const searchedEmployees = useMemo(() => {
    if (!searchQuery.trim()) return employees;
    const q = searchQuery.toLowerCase().trim();
    return employees.filter(
      (e) =>
        e.name.toLowerCase().includes(q) ||
        (e.employeeCode && e.employeeCode.toLowerCase().includes(q)) ||
        e.department.toLowerCase().includes(q) ||
        e.designation.toLowerCase().includes(q)
    );
  }, [employees, searchQuery]);

  // File Upload Handlers (Master only)
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setUploadErrorMsg('');
    setUploadSuccessMsg('');
    try {
      const parsed = await parseLeaveExcelFile(file, userId, employees);
      if (parsed.length === 0) {
        setUploadErrorMsg(
          isBn
            ? 'এক্সেল ফাইলে কোনো সঠিক কর্মচারীর ছুটির তথ্য পাওয়া যায়নি।'
            : 'No valid employee leave rows found in the Excel file.'
        );
      } else {
        setParsedPreviewList(parsed);
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'ফাইল রিড করতে ব্যর্থ হয়েছে';
      setUploadErrorMsg(msg);
    } finally {
      setUploading(false);
    }
  };

  const handleConfirmUpload = async () => {
    if (parsedPreviewList.length === 0) return;
    setUploading(true);
    try {
      await onBulkSaveLeaves(parsedPreviewList);
      setUploadSuccessMsg(
        isBn
          ? `সফলভাবে ${parsedPreviewList.length} জন কর্মচারীর ছুটির তথ্য ক্লাউড ডাটাবেজে সেভ হয়েছে!`
          : `Successfully saved ${parsedPreviewList.length} employee records to Cloud Database!`
      );
      setParsedPreviewList([]);
      setTimeout(() => {
        setIsUploadModalOpen(false);
        setUploadSuccessMsg('');
      }, 2000);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'আপলোড করতে সমস্যা হয়েছে';
      setUploadErrorMsg(msg);
    } finally {
      setUploading(false);
    }
  };

  // Quick edit leave balances (Master only)
  const handleStartEdit = () => {
    setEditingLeaveData({
      casualAllocated: currentLeave.casualAllocated,
      casualAvailed: currentLeave.casualAvailed,
      sickAllocated: currentLeave.sickAllocated,
      sickAvailed: currentLeave.sickAvailed,
      earnAllocated: currentLeave.earnAllocated,
      earnAvailed: currentLeave.earnAvailed,
      specialAllocated: currentLeave.specialAllocated,
      specialAvailed: currentLeave.specialAvailed,
      lwpAvailed: currentLeave.lwpAvailed,
    });
    setIsEditingLeaves(true);
  };

  const handleSaveLeaveEdit = async () => {
    const clAlloc = Number(editingLeaveData.casualAllocated ?? currentLeave.casualAllocated);
    const clAvail = Number(editingLeaveData.casualAvailed ?? currentLeave.casualAvailed);
    const slAlloc = Number(editingLeaveData.sickAllocated ?? currentLeave.sickAllocated);
    const slAvail = Number(editingLeaveData.sickAvailed ?? currentLeave.sickAvailed);
    const elAlloc = Number(editingLeaveData.earnAllocated ?? currentLeave.earnAllocated);
    const elAvail = Number(editingLeaveData.earnAvailed ?? currentLeave.earnAvailed);
    const spAlloc = Number(editingLeaveData.specialAllocated ?? currentLeave.specialAllocated);
    const spAvail = Number(editingLeaveData.specialAvailed ?? currentLeave.specialAvailed);
    const lwp = Number(editingLeaveData.lwpAvailed ?? currentLeave.lwpAvailed);

    const updated: EmployeeLeave = {
      ...currentLeave,
      casualAllocated: clAlloc,
      casualAvailed: clAvail,
      casualBalance: Math.max(0, clAlloc - clAvail),
      sickAllocated: slAlloc,
      sickAvailed: slAvail,
      sickBalance: Math.max(0, slAlloc - slAvail),
      earnAllocated: elAlloc,
      earnAvailed: elAvail,
      earnBalance: Math.max(0, elAlloc - elAvail),
      specialAllocated: spAlloc,
      specialAvailed: spAvail,
      specialBalance: 0,
      lwpAvailed: lwp,
      updatedAt: new Date().toISOString(),
    };

    await onSaveLeave(updated);
    setIsEditingLeaves(false);
  };

  const handleDeleteCurrent = async () => {
    if (!selectedEmployee || !onDeleteEmployee) return;
    const confirmMsg = isBn
      ? `আপনি কি নিশ্চিতভাবে কর্মচারী "${selectedEmployee.name}" (${selectedEmployee.employeeCode}) এবং ছুটির তথ্য ডিলিট করতে চান?`
      : `Are you sure you want to delete employee "${selectedEmployee.name}" (${selectedEmployee.employeeCode})?`;
    if (window.confirm(confirmMsg)) {
      setDeletingId(selectedEmployee.id);
      try {
        await onDeleteEmployee(selectedEmployee.id, currentLeave.id);
        const remaining = employees.filter((e) => e.id !== selectedEmployee.id);
        if (remaining.length > 0) {
          setSelectedEmpId(remaining[0].id);
        }
      } finally {
        setDeletingId(null);
      }
    }
  };

  const handlePrintCard = () => {
    window.print();
  };

  return (
    <div className="space-y-6 print:space-y-0 print:m-0 print:p-0">
      {/* 1. SINGLE CLEAN SEARCH & CONTROL BAR (Print:hidden) - Zero Duplication */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/90 shadow-xs print:hidden">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
          {/* Search by Employee ID or Name */}
          <div className="flex-1 w-full flex flex-col sm:flex-row gap-3 items-center">
            <div className="relative flex-1 w-full">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={
                  isBn
                    ? 'Employee ID (যেমন: EMP-001) অথবা নাম দিয়ে সার্চ করুন...'
                    : 'Search by Employee ID (e.g. EMP-001) or name...'
                }
                className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition"
              />
            </div>

            {/* Employee Dropdown Selector */}
            <div className="w-full sm:w-auto min-w-[260px]">
              <select
                value={selectedEmployee?.id || ''}
                onChange={(e) => {
                  setSelectedEmpId(e.target.value);
                  setSearchQuery('');
                }}
                className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none cursor-pointer"
              >
                {employees.map((emp) => (
                  <option key={emp.id} value={emp.id}>
                    {emp.employeeCode ? `[${emp.employeeCode}] ` : ''}
                    {emp.name} ({emp.designation})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Master User vs View Only Status & Action Buttons */}
          <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto justify-end">
            {isMasterUser ? (
              <>
                <button
                  onClick={() => downloadLeaveExcelTemplate(employees)}
                  className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition cursor-pointer"
                  title="Excel Format"
                >
                  <Download className="w-3.5 h-3.5 text-slate-600" />
                  <span>{isBn ? 'এক্সেল ফরম্যাট' : 'Excel Template'}</span>
                </button>

                <button
                  onClick={() => setIsUploadModalOpen(true)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs transition cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>{isBn ? 'Excel ছুটি আপলোড' : 'Bulk Upload'}</span>
                </button>

                {onOpenEmployeeModal && (
                  <button
                    onClick={onOpenEmployeeModal}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition cursor-pointer"
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    <span>{isBn ? '+ কর্মচারী যোগ' : '+ Add Staff'}</span>
                  </button>
                )}
              </>
            ) : (
              <div className="flex items-center gap-2">
                <span className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                  <Eye className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{isBn ? 'ভিউ অনলি মোড (View Only)' : 'View Only Mode'}</span>
                </span>
                {onOpenMasterLogin && (
                  <button
                    onClick={onOpenMasterLogin}
                    className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition cursor-pointer"
                  >
                    <ShieldCheck className="w-3.5 h-3.5 text-amber-600" />
                    <span>{isBn ? 'মাস্টার লগইন' : 'Master Login'}</span>
                  </button>
                )}
              </div>
            )}

            {onOpenShareModal && (
              <button
                onClick={onOpenShareModal}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-xl shadow-xs transition cursor-pointer"
                title={isBn ? 'সবার সাথে শেয়ার করার পাবলিক লিংক' : 'Share Public Link'}
              >
                <Share2 className="w-3.5 h-3.5 text-rose-600" />
                <span>{isBn ? 'শেয়ার লিংক' : 'Share'}</span>
              </button>
            )}

            <button
              onClick={handlePrintCard}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-xl transition cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5 text-slate-600" />
              <span>{isBn ? 'প্রিন্ট' : 'Print'}</span>
            </button>
          </div>
        </div>

        {/* Quick select pills when searching */}
        {searchedEmployees.length > 0 && searchQuery && (
          <div className="mt-3 pt-3 border-t border-slate-100 flex flex-wrap gap-2">
            <span className="text-xs text-slate-500 self-center">
              {isBn ? 'ফলাফল:' : 'Matching:'}
            </span>
            {searchedEmployees.slice(0, 6).map((emp) => (
              <button
                key={emp.id}
                onClick={() => {
                  setSelectedEmpId(emp.id);
                  setSearchQuery('');
                }}
                className={`px-2.5 py-1 text-xs rounded-lg font-medium transition cursor-pointer ${
                  selectedEmployee?.id === emp.id
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {emp.employeeCode ? `${emp.employeeCode} - ` : ''}
                {emp.name}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* 2. OFFICIAL EMPLOYEE LEAVE STATEMENT (The Singular Pristine Report Sheet) */}
      <div
        id="printable-employee-portal"
        className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden print:border print:border-slate-300 print:rounded-xl print:shadow-none print:m-0"
      >
        {/* Factory Header (Singular, Crisp, Official) */}
        <div className="p-6 print:p-3 border-b border-slate-200 bg-gradient-to-r from-slate-50 via-white to-slate-50 flex flex-col sm:flex-row items-center justify-between gap-4 print:gap-2">
          <div className="flex items-center gap-4 print:gap-3 text-center sm:text-left">
            <CompanyLogo size={52} className="w-13 h-13 print:w-10 print:h-10 shrink-0" />
            <div>
              <h1 className="text-xl sm:text-2xl print:text-lg font-black text-slate-900 tracking-tight leading-tight">
                Progress Apparels Bangladesh Ltd.
              </h1>
              <p className="text-xs sm:text-sm print:text-xs font-bold text-rose-800 tracking-wide mt-0.5 print:mt-0">
                {isBn
                  ? 'কর্মচারী ছুটির বিবরণী ও ব্যক্তিগত পোর্টাল (Employee Leave Ledger)'
                  : 'Employee Leave Ledger & Service Statement'}
              </p>
            </div>
          </div>

          <div className="text-right text-xs print:text-[11px] text-slate-500 font-mono">
            <p className="font-bold text-slate-800 text-sm print:text-xs">
              {isBn ? `বছর: ${currentLeave.year || 2026}` : `Year: ${currentLeave.year || 2026}`}
            </p>
            <p className="text-[11px] print:text-[10px] text-slate-400 mt-0.5">
              Ref: {currentLeave.employeeCode || 'EMP-001'}
            </p>
          </div>
        </div>

        {/* EMPLOYEE DASHBOARD / PROFILE BAR (ID, Name, Designation, Department, DOJ, Service Length) */}
        {/* Rendered ONCE in a clean 6-column information block - NO REPETITION! */}
        <div className="p-5 sm:p-6 print:p-3 bg-slate-900 text-white border-b border-slate-800">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 print:gap-2 pb-4 print:pb-2.5 mb-4 print:mb-2.5 border-b border-slate-800">
            <div className="flex items-center gap-3 print:gap-2.5">
              <div className="w-12 h-12 print:w-9 print:h-9 rounded-xl print:rounded-lg bg-gradient-to-tr from-rose-600 to-amber-600 flex items-center justify-center text-xl print:text-base font-black text-white shadow-md shrink-0">
                {selectedEmployee?.name?.charAt(0) || 'E'}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs print:text-[10px] font-mono font-black text-blue-300 bg-blue-900/60 px-2 print:px-1.5 py-0.5 rounded border border-blue-700/60">
                    ID: {selectedEmployee?.employeeCode || currentLeave.employeeCode || 'EMP-001'}
                  </span>
                  <span className="text-xs print:text-[10px] font-semibold text-emerald-300 bg-emerald-900/40 px-2 print:px-1.5 py-0.5 rounded border border-emerald-700/40">
                    {selectedEmployee?.status === 'active'
                      ? (isBn ? 'সক্রিয় স্টাফ' : 'Active')
                      : (isBn ? 'নিষ্ক্রিয়' : 'Inactive')}
                  </span>
                </div>
                <h2 className="text-xl sm:text-2xl print:text-base font-black text-white mt-0.5 tracking-tight leading-tight">
                  {selectedEmployee?.name || currentLeave.employeeName}
                </h2>
              </div>
            </div>

            {/* Master User Profile Management Controls (Modify / Delete Employee) */}
            {isMasterUser && selectedEmployee && (
              <div className="flex items-center gap-2 print:hidden">
                {onEditEmployee && (
                  <button
                    onClick={() => onEditEmployee(selectedEmployee)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-200 bg-blue-950/80 hover:bg-blue-900 border border-blue-700/60 rounded-lg transition cursor-pointer"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>{isBn ? 'কর্মচারী তথ্য পরিবর্তন' : 'Modify Employee'}</span>
                  </button>
                )}

                {onDeleteEmployee && (
                  <button
                    onClick={handleDeleteCurrent}
                    disabled={deletingId === selectedEmployee.id}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-rose-300 bg-rose-950/80 hover:bg-rose-900 border border-rose-700/60 rounded-lg transition cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{isBn ? 'ডিলিট করুন' : 'Delete'}</span>
                  </button>
                )}
              </div>
            )}
          </div>

          {/* Unified 5-Item Metadata Grid (ID, Designation, Department, DOJ, Service Length) */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 print:grid-cols-4 gap-3.5 sm:gap-4 print:gap-2 text-xs">
            {/* 1. Designation */}
            <div className="bg-slate-800/80 p-3 print:p-2 rounded-xl print:rounded-lg border border-slate-700/60">
              <span className="text-slate-400 text-[11px] print:text-[9px] font-medium block flex items-center gap-1">
                <Briefcase className="w-3 h-3 text-blue-400" />
                {isBn ? 'পদবী (Designation)' : 'Designation'}
              </span>
              <p className="font-bold text-white text-sm print:text-xs mt-1 print:mt-0.5 truncate">
                {selectedEmployee?.designation || currentLeave.designation}
              </p>
            </div>

            {/* 2. Department */}
            <div className="bg-slate-800/80 p-3 print:p-2 rounded-xl print:rounded-lg border border-slate-700/60">
              <span className="text-slate-400 text-[11px] print:text-[9px] font-medium block flex items-center gap-1">
                <Building className="w-3 h-3 text-indigo-400" />
                {isBn ? 'বিভাগ (Department)' : 'Department'}
              </span>
              <p className="font-bold text-white text-sm print:text-xs mt-1 print:mt-0.5 truncate">
                {selectedEmployee?.department || currentLeave.department}
              </p>
            </div>

            {/* 3. Date of Joining */}
            <div className="bg-slate-800/80 p-3 print:p-2 rounded-xl print:rounded-lg border border-slate-700/60">
              <span className="text-slate-400 text-[11px] print:text-[9px] font-medium block flex items-center gap-1">
                <Calendar className="w-3 h-3 text-amber-400" />
                {isBn ? 'যোগদান (DOJ)' : 'Joining Date'}
              </span>
              <p className="font-bold text-white text-sm print:text-xs mt-1 print:mt-0.5 font-mono">
                {selectedEmployee?.joiningDate || currentLeave.doj || '2023-01-15'}
              </p>
            </div>

            {/* 4. Service Length */}
            <div className="bg-slate-800/80 p-3 print:p-2 rounded-xl print:rounded-lg border border-amber-500/30 col-span-2 sm:col-span-1 lg:col-span-2 print:col-span-1">
              <span className="text-amber-300 text-[11px] print:text-[9px] font-bold block flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                {isBn ? 'চাকরির মেয়াদ (Service Length)' : 'Service Length'}
              </span>
              <p className="font-black text-amber-300 text-sm sm:text-base print:text-xs mt-1 print:mt-0.5">
                {serviceLength.text}
              </p>
            </div>
          </div>
        </div>

        {/* 3. LEAVE TABLE & BALANCE (Singular Table Matching User's Required Columns) */}
        <div>
          {/* Table Header Controls */}
          <div className="p-4 sm:p-5 print:p-2.5 border-b border-slate-200 flex justify-between items-center bg-slate-50/50">
            <div>
              <h3 className="font-black text-base print:text-sm text-slate-900 flex items-center gap-2">
                <span>{isBn ? 'ছুটির বিবরণী ও ব্যালেন্স' : 'Leave Quota & Balance Ledger'}</span>
                <span className="text-xs print:text-[10px] font-semibold px-2 py-0.5 rounded bg-blue-100 text-blue-800">
                  {currentLeave.year || 2026}
                </span>
              </h3>
              <p className="text-xs print:text-[10px] text-slate-500 mt-0.5 print:mt-0">
                {isBn
                  ? 'বরাদ্দকৃত ছুটি, গৃহীত ছুটি এবং অবশিষ্ট ব্যালেন্সের হিসাব'
                  : 'Official breakdown of allocated, availed, and balance leave days'}
              </p>
            </div>

            {/* Master User Edit Controls */}
            {isMasterUser && (
              <div className="flex items-center gap-2 print:hidden">
                {!isEditingLeaves ? (
                  <button
                    onClick={handleStartEdit}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition cursor-pointer"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>{isBn ? 'ছুটির ডাটা এডিট (Modify)' : 'Modify Leave Data'}</span>
                  </button>
                ) : (
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setIsEditingLeaves(false)}
                      className="px-2.5 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-200 rounded-lg transition cursor-pointer"
                    >
                      {isBn ? 'বাতিল' : 'Cancel'}
                    </button>
                    <button
                      onClick={handleSaveLeaveEdit}
                      className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition cursor-pointer"
                    >
                      <Save className="w-3.5 h-3.5" />
                      <span>{isBn ? 'সেভ করুন' : 'Save Changes'}</span>
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Table Content */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm border-collapse">
              <thead>
                <tr className="bg-slate-900 text-white text-xs print:text-[11px] uppercase font-bold tracking-wider">
                  <th className="py-3.5 px-6 print:py-1.5 print:px-3 border-b border-slate-800">
                    {isBn ? 'ছুটির ধরন (Leave Type)' : 'Leave Type'}
                  </th>
                  <th className="py-3.5 px-6 print:py-1.5 print:px-3 text-center border-b border-slate-800">
                    {isBn ? 'বরাদ্দকৃত ছুটি (Leave Allocated)' : 'Leave Allocated'}
                  </th>
                  <th className="py-3.5 px-6 print:py-1.5 print:px-3 text-center border-b border-slate-800">
                    {isBn ? 'ভোগকৃত ছুটি (Availed)' : 'Availed'}
                  </th>
                  <th className="py-3.5 px-6 print:py-1.5 print:px-3 text-center border-b border-slate-800">
                    {isBn ? 'অবশিষ্ট ব্যালেন্স (Balance)' : 'Balance'}
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 font-medium text-slate-800 text-sm print:text-xs">
                {/* 1. Casual Leave (CL) */}
                <tr className="hover:bg-slate-50/80 transition">
                  <td className="py-3.5 px-6 print:py-1.5 print:px-3 font-semibold text-slate-900 flex items-center gap-2">
                    <span className="w-2.5 h-2.5 print:w-2 print:h-2 rounded-full bg-blue-600"></span>
                    <span>Casual Leave (CL)</span>
                    <span className="text-xs print:text-[10px] text-slate-400 font-normal">{isBn ? '(নৈমিত্তিক ছুটি)' : ''}</span>
                  </td>
                  <td className="py-3.5 px-6 print:py-1.5 print:px-3 text-center font-bold text-slate-700">
                    {isEditingLeaves ? (
                      <input
                        type="number"
                        min="0"
                        value={editingLeaveData.casualAllocated}
                        onChange={(e) =>
                          setEditingLeaveData((prev) => ({
                            ...prev,
                            casualAllocated: Number(e.target.value),
                          }))
                        }
                        className="w-16 px-2 py-1 text-xs border border-blue-300 rounded text-center outline-none focus:ring-1 focus:ring-blue-500 font-bold"
                      />
                    ) : (
                      currentLeave.casualAllocated
                    )}
                  </td>
                  <td className="py-3.5 px-6 print:py-1.5 print:px-3 text-center font-bold text-amber-600">
                    {isEditingLeaves ? (
                      <input
                        type="number"
                        min="0"
                        value={editingLeaveData.casualAvailed}
                        onChange={(e) =>
                          setEditingLeaveData((prev) => ({
                            ...prev,
                            casualAvailed: Number(e.target.value),
                          }))
                        }
                        className="w-16 px-2 py-1 text-xs border border-amber-300 rounded text-center outline-none focus:ring-1 focus:ring-blue-500 font-bold"
                      />
                    ) : (
                      currentLeave.casualAvailed
                    )}
                  </td>
                  <td className="py-3.5 px-6 print:py-1.5 print:px-3 text-center font-black text-emerald-600 text-base print:text-xs">
                    {isEditingLeaves
                      ? Math.max(
                          0,
                          Number(editingLeaveData.casualAllocated ?? 0) -
                            Number(editingLeaveData.casualAvailed ?? 0)
                        )
                      : currentLeave.casualBalance}
                  </td>
                </tr>

                {/* 2. Sick Leave (SL) */}
                <tr className="hover:bg-slate-50/80 transition bg-slate-50/30">
                  <td className="py-3.5 px-6 print:py-1.5 print:px-3 font-semibold text-slate-900 flex items-center gap-2">
                    <span className="w-2.5 h-2.5 print:w-2 print:h-2 rounded-full bg-rose-500"></span>
                    <span>Sick Leave (SL)</span>
                    <span className="text-xs print:text-[10px] text-slate-400 font-normal">{isBn ? '(অসুস্থতাজনিত ছুটি)' : ''}</span>
                  </td>
                  <td className="py-3.5 px-6 print:py-1.5 print:px-3 text-center font-bold text-slate-700">
                    {isEditingLeaves ? (
                      <input
                        type="number"
                        min="0"
                        value={editingLeaveData.sickAllocated}
                        onChange={(e) =>
                          setEditingLeaveData((prev) => ({
                            ...prev,
                            sickAllocated: Number(e.target.value),
                          }))
                        }
                        className="w-16 px-2 py-1 text-xs border border-blue-300 rounded text-center outline-none focus:ring-1 focus:ring-blue-500 font-bold"
                      />
                    ) : (
                      currentLeave.sickAllocated
                    )}
                  </td>
                  <td className="py-3.5 px-6 print:py-1.5 print:px-3 text-center font-bold text-amber-600">
                    {isEditingLeaves ? (
                      <input
                        type="number"
                        min="0"
                        value={editingLeaveData.sickAvailed}
                        onChange={(e) =>
                          setEditingLeaveData((prev) => ({
                            ...prev,
                            sickAvailed: Number(e.target.value),
                          }))
                        }
                        className="w-16 px-2 py-1 text-xs border border-amber-300 rounded text-center outline-none focus:ring-1 focus:ring-blue-500 font-bold"
                      />
                    ) : (
                      currentLeave.sickAvailed
                    )}
                  </td>
                  <td className="py-3.5 px-6 print:py-1.5 print:px-3 text-center font-black text-emerald-600 text-base print:text-xs">
                    {isEditingLeaves
                      ? Math.max(
                          0,
                          Number(editingLeaveData.sickAllocated ?? 0) -
                            Number(editingLeaveData.sickAvailed ?? 0)
                        )
                      : currentLeave.sickBalance}
                  </td>
                </tr>

                {/* 3. Earn Leave (EL) */}
                <tr className="hover:bg-slate-50/80 transition">
                  <td className="py-3.5 px-6 print:py-1.5 print:px-3 font-semibold text-slate-900 flex items-center gap-2">
                    <span className="w-2.5 h-2.5 print:w-2 print:h-2 rounded-full bg-emerald-500"></span>
                    <span>Earn Leave (EL)</span>
                    <span className="text-xs print:text-[10px] text-slate-400 font-normal">{isBn ? '(অর্জিত ছুটি)' : ''}</span>
                  </td>
                  <td className="py-3.5 px-6 print:py-1.5 print:px-3 text-center font-bold text-slate-700">
                    {isEditingLeaves ? (
                      <input
                        type="number"
                        min="0"
                        value={editingLeaveData.earnAllocated}
                        onChange={(e) =>
                          setEditingLeaveData((prev) => ({
                            ...prev,
                            earnAllocated: Number(e.target.value),
                          }))
                        }
                        className="w-16 px-2 py-1 text-xs border border-blue-300 rounded text-center outline-none focus:ring-1 focus:ring-blue-500 font-bold"
                      />
                    ) : (
                      currentLeave.earnAllocated
                    )}
                  </td>
                  <td className="py-3.5 px-6 print:py-1.5 print:px-3 text-center font-bold text-amber-600">
                    {isEditingLeaves ? (
                      <input
                        type="number"
                        min="0"
                        value={editingLeaveData.earnAvailed}
                        onChange={(e) =>
                          setEditingLeaveData((prev) => ({
                            ...prev,
                            earnAvailed: Number(e.target.value),
                          }))
                        }
                        className="w-16 px-2 py-1 text-xs border border-amber-300 rounded text-center outline-none focus:ring-1 focus:ring-blue-500 font-bold"
                      />
                    ) : (
                      currentLeave.earnAvailed
                    )}
                  </td>
                  <td className="py-3.5 px-6 print:py-1.5 print:px-3 text-center font-black text-emerald-600 text-base print:text-xs">
                    {isEditingLeaves
                      ? Math.max(
                          0,
                          Number(editingLeaveData.earnAllocated ?? 0) -
                            Number(editingLeaveData.earnAvailed ?? 0)
                        )
                      : currentLeave.earnBalance}
                  </td>
                </tr>

                {/* 4. Special Leave (Zero balance per user constraint) */}
                <tr className="hover:bg-slate-50/80 transition bg-slate-50/30">
                  <td className="py-3.5 px-6 print:py-1.5 print:px-3 font-semibold text-slate-900 flex items-center gap-2">
                    <span className="w-2.5 h-2.5 print:w-2 print:h-2 rounded-full bg-purple-500"></span>
                    <span>Special Leave</span>
                    <span className="text-xs print:text-[10px] text-slate-400 font-normal">{isBn ? '(বিশেষ ছুটি)' : ''}</span>
                  </td>
                  <td className="py-3.5 px-6 print:py-1.5 print:px-3 text-center font-bold text-slate-700">
                    {isEditingLeaves ? (
                      <input
                        type="number"
                        min="0"
                        value={editingLeaveData.specialAllocated}
                        onChange={(e) =>
                          setEditingLeaveData((prev) => ({
                            ...prev,
                            specialAllocated: Number(e.target.value),
                          }))
                        }
                        className="w-16 px-2 py-1 text-xs border border-blue-300 rounded text-center outline-none focus:ring-1 focus:ring-blue-500 font-bold"
                      />
                    ) : (
                      currentLeave.specialAllocated
                    )}
                  </td>
                  <td className="py-3.5 px-6 print:py-1.5 print:px-3 text-center font-bold text-amber-600">
                    {isEditingLeaves ? (
                      <input
                        type="number"
                        min="0"
                        value={editingLeaveData.specialAvailed}
                        onChange={(e) =>
                          setEditingLeaveData((prev) => ({
                            ...prev,
                            specialAvailed: Number(e.target.value),
                          }))
                        }
                        className="w-16 px-2 py-1 text-xs border border-amber-300 rounded text-center outline-none focus:ring-1 focus:ring-blue-500 font-bold"
                      />
                    ) : (
                      currentLeave.specialAvailed
                    )}
                  </td>
                  <td className="py-3.5 px-6 print:py-1.5 print:px-3 text-center text-slate-400 font-mono font-medium text-sm print:text-xs">
                    -
                  </td>
                </tr>

                {/* 5. Leave without Pay (Zero balance per user constraint) */}
                <tr className="hover:bg-slate-50/80 transition">
                  <td className="py-3.5 px-6 print:py-1.5 print:px-3 font-semibold text-slate-900 flex items-center gap-2">
                    <span className="w-2.5 h-2.5 print:w-2 print:h-2 rounded-full bg-rose-400"></span>
                    <span>Leave without Pay</span>
                    <span className="text-xs print:text-[10px] text-slate-400 font-normal">{isBn ? '(অবৈতনিক ছুটি)' : ''}</span>
                  </td>
                  <td className="py-3.5 px-6 print:py-1.5 print:px-3 text-center text-slate-400 font-mono">-</td>
                  <td className="py-3.5 px-6 print:py-1.5 print:px-3 text-center font-bold text-rose-600">
                    {isEditingLeaves ? (
                      <input
                        type="number"
                        min="0"
                        value={editingLeaveData.lwpAvailed}
                        onChange={(e) =>
                          setEditingLeaveData((prev) => ({
                            ...prev,
                            lwpAvailed: Number(e.target.value),
                          }))
                        }
                        className="w-16 px-2 py-1 text-xs border border-rose-300 rounded text-center outline-none focus:ring-1 focus:ring-blue-500 font-bold"
                      />
                    ) : (
                      currentLeave.lwpAvailed
                    )}
                  </td>
                  <td className="py-3.5 px-6 print:py-1.5 print:px-3 text-center text-slate-400 font-mono font-medium text-sm print:text-xs">
                    -
                  </td>
                </tr>
              </tbody>

              {/* Total Calculation Row */}
              <tfoot>
                <tr className="bg-slate-100 font-bold text-slate-900 text-sm print:text-xs border-t-2 border-slate-300">
                  <td className="py-3.5 px-6 print:py-2 print:px-3 uppercase tracking-wider">
                    {isBn ? 'সর্বমোট ছুটি (Total Leave)' : 'Total Leave'}
                  </td>
                  <td className="py-3.5 px-6 print:py-2 print:px-3 text-center font-black text-base print:text-xs text-slate-800">
                    {currentLeave.casualAllocated +
                      currentLeave.sickAllocated +
                      currentLeave.earnAllocated +
                      currentLeave.specialAllocated}
                  </td>
                  <td className="py-3.5 px-6 print:py-2 print:px-3 text-center font-black text-base print:text-xs text-amber-700">
                    {currentLeave.casualAvailed +
                      currentLeave.sickAvailed +
                      currentLeave.earnAvailed +
                      currentLeave.specialAvailed +
                      currentLeave.lwpAvailed}
                  </td>
                  <td className="py-3.5 px-6 print:py-2 print:px-3 text-center font-black text-lg print:text-sm text-emerald-700">
                    {currentLeave.casualBalance +
                      currentLeave.sickBalance +
                      currentLeave.earnBalance}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Official Report Prepared By Section (Signatures removed per user request) */}
          <div className="p-5 print:p-2 bg-slate-50/70 border-t border-slate-200">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 print:gap-2 bg-white p-4 print:p-2 rounded-xl border border-slate-200 shadow-xs print:shadow-none">
              <div className="flex items-center gap-3 print:gap-2">
                <div className="w-10 h-10 print:w-7 print:h-7 rounded-xl print:rounded-lg bg-rose-50 border border-rose-200 flex items-center justify-center font-black text-rose-700 text-xs print:text-[9px]">
                  HR
                </div>
                <div>
                  <p className="text-[10px] print:text-[8px] font-bold text-slate-400 uppercase tracking-wider">
                    Report Prepared By
                  </p>
                  <p className="font-extrabold text-slate-900 text-sm print:text-xs tracking-wide">
                    AL-AMIN
                  </p>
                  <p className="text-xs print:text-[10px] font-bold text-rose-800">
                    Assistant Manager-HR
                  </p>
                </div>
              </div>

              <div className="text-left sm:text-right text-xs text-slate-500 font-medium">
                <p className="font-semibold text-slate-700 print:text-[10px]">Progress Apparels Bangladesh Ltd.</p>
                <p className="text-[11px] print:text-[9px] text-slate-400 font-mono mt-0.5">
                  Generated: {new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 4. MASTER BULK EXCEL UPLOAD MODAL */}
      {isUploadModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full p-6 border border-slate-200 relative my-8">
            <div className="flex justify-between items-center pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
                  <FileSpreadsheet className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-slate-800">
                    {isBn ? 'Excel থেকে সব কর্মচারীর ছুটি আপলোড' : 'Bulk Upload Leaves via Excel'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {isBn
                      ? '.xlsx বা .xls ফাইল থেকে এক ক্লিকে সবার ছুটি ক্লাউড ডাটাবেজে সেভ করুন'
                      : 'Upload all staff leave quotas and balances at once from spreadsheet'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  setIsUploadModalOpen(false);
                  setParsedPreviewList([]);
                  setUploadErrorMsg('');
                  setUploadSuccessMsg('');
                }}
                className="p-1.5 hover:bg-slate-100 text-slate-400 hover:text-slate-600 rounded-lg transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {uploadErrorMsg && (
              <div className="mt-4 p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{uploadErrorMsg}</span>
              </div>
            )}

            {uploadSuccessMsg && (
              <div className="mt-4 p-3 bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs rounded-xl flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{uploadSuccessMsg}</span>
              </div>
            )}

            {/* Upload Area */}
            <div className="mt-5 space-y-4">
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-slate-300 hover:border-emerald-500 rounded-2xl p-8 text-center cursor-pointer bg-slate-50/60 hover:bg-emerald-50/20 transition group"
              >
                <FileSpreadsheet className="w-12 h-12 text-slate-400 group-hover:text-emerald-600 mx-auto mb-2 transition" />
                <p className="text-sm font-semibold text-slate-700 group-hover:text-emerald-700">
                  {isBn
                    ? 'আপনার এক্সেল ফাইলটি নির্বাচন করতে এখানে ক্লিক করুন'
                    : 'Click to select your Excel file (.xlsx / .xls)'}
                </p>
                <p className="text-xs text-slate-400 mt-1">
                  {isBn
                    ? 'কলাম: Employee ID, Employee Name, Designation, Department, DOJ, CL, SL, EL, Special, LWP'
                    : 'Columns: Employee ID, Employee Name, Designation, Department, DOJ, CL, SL, EL, Special, LWP'}
                </p>
                <input
                  type="file"
                  ref={fileInputRef}
                  accept=".xlsx, .xls, .csv"
                  onChange={handleFileChange}
                  className="hidden"
                />
              </div>

              {/* Sample format hint */}
              <div className="flex justify-between items-center bg-blue-50/70 p-3.5 rounded-xl border border-blue-100 text-xs">
                <div className="flex items-center gap-2 text-blue-900">
                  <Info className="w-4 h-4 text-blue-600 shrink-0" />
                  <span>
                    {isBn
                      ? 'সঠিক ফরম্যাটের জন্য আমাদের তৈরি এক্সেল টেমপ্লেটটি ডাউনলোড করুন:'
                      : 'Download standard template with sample rows:'}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => downloadLeaveExcelTemplate(employees)}
                  className="inline-flex items-center gap-1 font-bold text-blue-700 hover:text-blue-900 bg-white px-3 py-1.5 rounded-lg border border-blue-200 shadow-xs cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{isBn ? 'টেমপ্লেট ডাউনলোড' : 'Download Template'}</span>
                </button>
              </div>

              {/* Preview Table of Parsed Leaves */}
              {parsedPreviewList.length > 0 && (
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold text-slate-700">
                      {isBn
                        ? `ফাইল থেকে পড়া হয়েছে: ${parsedPreviewList.length} জন কর্মচারীর ছুটির রেকর্ড`
                        : `Parsed ${parsedPreviewList.length} records:`}
                    </span>
                    <span className="text-xs text-emerald-600 font-semibold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      {isBn ? 'যাচাই সফল' : 'Verified'}
                    </span>
                  </div>

                  <div className="max-h-56 overflow-y-auto border border-slate-200 rounded-xl">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead className="bg-slate-100 text-slate-700 font-bold sticky top-0">
                        <tr>
                          <th className="p-2 border-b">ID</th>
                          <th className="p-2 border-b">Name</th>
                          <th className="p-2 border-b text-center">CL Bal</th>
                          <th className="p-2 border-b text-center">SL Bal</th>
                          <th className="p-2 border-b text-center">EL Bal</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {parsedPreviewList.slice(0, 10).map((l, i) => (
                          <tr key={i} className="hover:bg-slate-50">
                            <td className="p-2 font-mono font-bold text-blue-600">
                              {l.employeeCode}
                            </td>
                            <td className="p-2 font-medium text-slate-800">
                              {l.employeeName}
                            </td>
                            <td className="p-2 text-center text-emerald-600 font-bold">
                              {l.casualBalance}
                            </td>
                            <td className="p-2 text-center text-emerald-600 font-bold">
                              {l.sickBalance}
                            </td>
                            <td className="p-2 text-center text-emerald-600 font-bold">
                              {l.earnBalance}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {parsedPreviewList.length > 10 && (
                      <p className="text-[11px] text-center text-slate-400 py-1 bg-slate-50">
                        + আরো {parsedPreviewList.length - 10} টি রেকর্ড...
                      </p>
                    )}
                  </div>

                  {/* Confirm Upload Button */}
                  <button
                    onClick={handleConfirmUpload}
                    disabled={uploading}
                    className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 disabled:bg-emerald-400 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Upload className="w-4 h-4" />
                    <span>
                      {uploading
                        ? (isBn ? 'ক্লাউডে সেভ হচ্ছে...' : 'Saving to Cloud...')
                        : (isBn
                            ? `সবার ছুটির ডাটা ক্লাউডে সেভ করুন (${parsedPreviewList.length} জন)`
                            : `Confirm & Save ${parsedPreviewList.length} Staff Leaves to Cloud`)}
                    </span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
