import React from 'react';
import {
  ShieldCheck,
  Globe,
  Upload,
  UserPlus,
  Download,
  Printer,
  Lock,
  Crown,
  LogOut,
  Eye,
  Share2,
} from 'lucide-react';
import type { User } from 'firebase/auth';
import { CompanyLogo } from './CompanyLogo';

interface NavbarProps {
  user: User | null;
  isMasterUser: boolean;
  onLogout: () => void;
  onOpenMasterLogin: () => void;
  language: 'bn' | 'en';
  setLanguage: (lang: 'bn' | 'en') => void;
  onOpenUploadModal: () => void;
  onOpenEmployeeModal: () => void;
  onDownloadTemplate: () => void;
  onPrint: () => void;
  onOpenShareModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  isMasterUser,
  onLogout,
  onOpenMasterLogin,
  language,
  setLanguage,
  onOpenUploadModal,
  onOpenEmployeeModal,
  onDownloadTemplate,
  onPrint,
  onOpenShareModal,
}) => {
  const isBn = language === 'bn';

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/90 shadow-xs print:hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16 sm:h-18">
          {/* Logo & Factory Name - Clean & Singular */}
          <div className="flex items-center gap-3">
            <CompanyLogo size={42} className="w-10 h-10 sm:w-11 sm:h-11 shrink-0" />
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-slate-900 text-sm sm:text-base tracking-tight">
                  Progress Apparels Bangladesh Ltd.
                </span>
                {isMasterUser ? (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-amber-50 text-amber-800 border border-amber-300">
                    <Crown className="w-3 h-3 text-amber-600" />
                    <span>{isBn ? 'মাস্টার ইউজার' : 'Master User'}</span>
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
                    <Eye className="w-3 h-3 text-emerald-600" />
                    <span>{isBn ? 'ভিউ অনলি' : 'View Only'}</span>
                  </span>
                )}
              </div>
              <p className="text-xs text-rose-800 font-semibold">
                {isBn ? 'কর্মচারী ছুটির পোর্টাল (Employee Leave Portal)' : 'Employee Leave Portal'}
              </p>
            </div>
          </div>

          {/* Right Action Controls */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Master User Controls: Upload, Add Staff, Template */}
            {isMasterUser ? (
              <div className="flex items-center gap-1.5 sm:gap-2">
                <button
                  onClick={onDownloadTemplate}
                  className="hidden md:inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition cursor-pointer"
                  title="Excel Template"
                >
                  <Download className="w-3.5 h-3.5 text-slate-600" />
                  <span>{isBn ? 'টেমপ্লেট' : 'Template'}</span>
                </button>

                <button
                  onClick={onOpenUploadModal}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-xs transition cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">{isBn ? 'Excel আপলোড' : 'Bulk Upload'}</span>
                  <span className="sm:hidden">{isBn ? 'আপলোড' : 'Upload'}</span>
                </button>

                <button
                  onClick={onOpenEmployeeModal}
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition cursor-pointer"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">{isBn ? '+ কর্মচারী যোগ' : '+ Staff'}</span>
                </button>

                <button
                  onClick={onLogout}
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-slate-700 hover:text-rose-700 bg-slate-100 hover:bg-rose-50 rounded-lg border border-slate-200 transition cursor-pointer"
                  title="Exit Master Mode"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span className="hidden md:inline">{isBn ? 'লগআউট' : 'Exit'}</span>
                </button>
              </div>
            ) : (
              <button
                onClick={onOpenMasterLogin}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-xs transition cursor-pointer"
                title="Master User Login"
              >
                <Lock className="w-3.5 h-3.5 text-amber-400" />
                <span>{isBn ? 'মাস্টার লগইন' : 'Master Login'}</span>
              </button>
            )}

            {/* Share Public Link Button - Easily share with all employees */}
            <button
              onClick={onOpenShareModal}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-lg shadow-xs transition cursor-pointer"
              title={isBn ? 'সবার সাথে শেয়ার করার লিংক' : 'Share Public Link'}
            >
              <Share2 className="w-3.5 h-3.5 text-rose-600" />
              <span>{isBn ? 'শেয়ার লিংক' : 'Share Link'}</span>
            </button>

            {/* Print Button - Available to everyone */}
            <button
              onClick={onPrint}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition cursor-pointer"
              title="Print Statement"
            >
              <Printer className="w-3.5 h-3.5 text-slate-600" />
              <span className="hidden sm:inline">{isBn ? 'প্রিন্ট' : 'Print'}</span>
            </button>

            {/* Language Switch */}
            <button
              onClick={() => setLanguage(isBn ? 'en' : 'bn')}
              className="inline-flex items-center gap-1 px-2 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition cursor-pointer"
              title="Change Language"
            >
              <Globe className="w-3.5 h-3.5 text-slate-500" />
              <span>{isBn ? 'EN' : 'বাং'}</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
