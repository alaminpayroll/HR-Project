import React, { useState } from 'react';
import {
  Settings,
  Building,
  DollarSign,
  Calendar,
  Clock,
  Database,
  Save,
  Download,
  ShieldCheck,
  Check,
} from 'lucide-react';
import type { CompanySetting, Employee, AttendanceRecord, PayrollRecord, AdvanceLoan } from '../types';

interface SettingsViewProps {
  settings: CompanySetting;
  employees: Employee[];
  attendance: AttendanceRecord[];
  payrolls: PayrollRecord[];
  advances: AdvanceLoan[];
  isBn: boolean;
  onSaveSettings: (settings: CompanySetting) => Promise<void>;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  employees,
  attendance,
  payrolls,
  advances,
  isBn,
  onSaveSettings,
}) => {
  const [companyName, setCompanyName] = useState(settings.companyName || 'Al-Amin Business Enterprise');
  const [phone, setPhone] = useState(settings.phone || '');
  const [currency, setCurrency] = useState(settings.currency || '৳');
  const [workingDays, setWorkingDays] = useState(settings.workingDaysPerMonth?.toString() || '26');
  const [overtimeRate, setOvertimeRate] = useState(settings.overtimeRatePerHour?.toString() || '100');
  const [saving, setSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSavedSuccess(false);

    try {
      const updated: CompanySetting = {
        ...settings,
        companyName: companyName.trim().slice(0, 100),
        phone: phone.trim().slice(0, 30),
        currency: currency.trim().slice(0, 10),
        workingDaysPerMonth: parseInt(workingDays, 10) || 26,
        overtimeRatePerHour: parseFloat(overtimeRate) || 100,
        updatedAt: new Date().toISOString(),
      };

      await onSaveSettings(updated);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    } finally {
      setSaving(false);
    }
  };

  const handleExportData = () => {
    const backupData = {
      exportDate: new Date().toISOString(),
      company: companyName,
      settings,
      employees,
      attendance,
      payrolls,
      advances,
    };

    const blob = new Blob([JSON.stringify(backupData, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `alamin-payroll-backup-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Cloud Persistence Guarantee Card */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs relative overflow-hidden">
        <div className="flex items-start gap-4">
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
            <Database className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-base text-slate-900">
                {isBn ? 'ক্লাউড ডাটাবেজ স্টোরেজ তথ্য (Firestore Persistence)' : 'Cloud Database Storage'}
              </h3>
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
                <ShieldCheck className="w-3.5 h-3.5" />
                {isBn ? 'সুরক্ষিত ও সক্রিয়' : 'Active & Protected'}
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-600 mt-1 leading-relaxed">
              {isBn
                ? 'আপনার আগের লিংকে ডাটা সেভ না থাকার কারণ ছিল ক্লাউড ডাটাবেজ সংযুক্ত না থাকা। এখন এই অ্যাপটিতে Google Firebase Firestore সরাসরি কনফিগার করা হয়েছে। পেজ রিলোড দেওয়া হোক বা যেকোনো নতুন ডিভাইস থেকে ওপেন করা হোক—আপনার কর্মচারী, বেতন এবং হাজিরার তথ্য সবসময় সুরক্ষিত থাকবে।'
                : 'All your employee, attendance, payroll, and advance records are stored in Google Cloud Firestore. Reloading the page or visiting from a different browser or phone will never lose your data.'}
            </p>
            <div className="mt-3 flex flex-wrap gap-2 text-xs font-mono text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-200">
              <div>
                <span className="text-slate-400">Database ID: </span>
                <span className="font-bold text-slate-800">ai-studio-fe3ddee5-2c0b-4db6-9de0-446dcea534d8</span>
              </div>
              <div className="ml-0 sm:ml-4">
                <span className="text-slate-400">Cloud Sync: </span>
                <span className="text-emerald-600 font-bold">Real-time bi-directional</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Settings Form */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs">
        <h3 className="font-bold text-base text-slate-900 mb-4 flex items-center gap-2">
          <Settings className="w-5 h-5 text-blue-600" />
          {isBn ? 'কোম্পানি ও পেরোল কনফিগারেশন' : 'Company & Payroll Settings'}
        </h3>

        {savedSuccess && (
          <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold flex items-center gap-1.5">
            <Check className="w-4 h-4 text-emerald-600" />
            {isBn ? 'সেটিংস সফলভাবে সংরক্ষিত হয়েছে!' : 'Settings updated successfully!'}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
              <Building className="w-3.5 h-3.5 text-slate-400" />
              {isBn ? 'কোম্পানি / প্রতিষ্ঠানের নাম *' : 'Company Name *'}
            </label>
            <input
              type="text"
              required
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
              className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition font-medium"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {isBn ? 'অফিসিয়াল যোগাযোগ ফোন' : 'Contact Phone'}
              </label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="017xxxxxxxx"
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
                <DollarSign className="w-3.5 h-3.5 text-slate-400" />
                {isBn ? 'মুদ্রার প্রতীক (Currency)' : 'Currency Symbol'}
              </label>
              <input
                type="text"
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
                placeholder="৳ বা $"
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none font-bold text-slate-800 transition"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                {isBn ? 'মাসে সাধারণ কর্মদিবস (দিন)' : 'Working Days / Month'}
              </label>
              <input
                type="number"
                min="1"
                max="31"
                value={workingDays}
                onChange={(e) => setWorkingDays(e.target.value)}
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition font-semibold"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                {isBn ? 'ঘণ্টাপ্রতি ওভারটাইম রেট (৳)' : 'Overtime Rate / Hour'}
              </label>
              <input
                type="number"
                min="0"
                value={overtimeRate}
                onChange={(e) => setOvertimeRate(e.target.value)}
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition font-semibold"
              />
            </div>
          </div>

          <div className="pt-4 flex justify-between items-center border-t border-slate-100">
            <button
              type="button"
              onClick={handleExportData}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition cursor-pointer"
            >
              <Download className="w-4 h-4" />
              {isBn ? 'সকল ডাটা ব্যাকআপ ডাউনলোড (JSON)' : 'Export Backup (JSON)'}
            </button>

            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center gap-1.5 px-5 py-2 text-xs sm:text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition disabled:opacity-50 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              {saving ? (isBn ? 'সংরক্ষণ হচ্ছে...' : 'Saving...') : (isBn ? 'সেটিংস সেভ করুন' : 'Save Settings')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
