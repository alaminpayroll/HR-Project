import React from 'react';
import { X, Printer, CheckCircle } from 'lucide-react';
import type { PayrollRecord, Employee, CompanySetting } from '../types';

interface PayslipModalProps {
  record: PayrollRecord;
  employee?: Employee;
  settings?: CompanySetting;
  currency: string;
  onClose: () => void;
}

export const PayslipModal: React.FC<PayslipModalProps> = ({
  record,
  employee,
  settings,
  currency,
  onClose,
}) => {
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full p-6 border border-slate-200 relative my-8 print:p-0 print:border-none print:shadow-none">
        {/* Modal Controls */}
        <div className="flex justify-between items-center pb-4 border-b border-slate-100 print:hidden">
          <h3 className="font-semibold text-lg text-slate-800">বেতন স্লিপ (Payslip)</h3>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-medium transition cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              প্রিন্ট / PDF
            </button>
            <button
              onClick={onClose}
              className="p-2 hover:bg-slate-100 text-slate-500 rounded-lg transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Payslip Body */}
        <div id="printable-payslip" className="pt-4 text-slate-800">
          {/* Header */}
          <div className="text-center pb-6 border-b border-slate-200">
            <h1 className="text-2xl font-bold text-slate-900">
              {settings?.companyName || 'Al-Amin Business & Enterprise'}
            </h1>
            <p className="text-sm text-slate-500 mt-0.5">
              {settings?.phone ? `ফোন: ${settings.phone} | ` : ''}
              মাসিক বেতন ভাউচার / Salary Disbursement Slip
            </p>
            <div className="inline-block mt-3 px-4 py-1 bg-slate-100 text-slate-700 rounded-full text-xs font-semibold uppercase tracking-wider">
              বেতন মাস: {record.monthYear}
            </div>
          </div>

          {/* Employee & Record Info */}
          <div className="grid grid-cols-2 gap-4 py-4 text-sm border-b border-slate-200 bg-slate-50/70 p-4 rounded-xl mt-4">
            <div>
              <p className="text-slate-500 text-xs">কর্মচারীর নাম:</p>
              <p className="font-bold text-slate-900 text-base">{record.employeeName}</p>
              <p className="text-xs text-slate-600 mt-1">
                পদবী: {employee?.designation || 'কর্মচারী'}
              </p>
              <p className="text-xs text-slate-600">
                বিভাগ: {employee?.department || 'জেনারেল'}
              </p>
            </div>
            <div className="text-right">
              <p className="text-slate-500 text-xs">আইডি নম্বর:</p>
              <p className="font-mono text-xs text-slate-700">{record.employeeId.slice(0, 10)}</p>
              <p className="text-xs text-slate-600 mt-1">
                পেমেন্ট মাধ্যম: <span className="font-medium capitalize">{record.paymentMethod}</span>
              </p>
              <p className="text-xs text-slate-600">
                তারিখ: {record.paymentDate || new Date().toISOString().split('T')[0]}
              </p>
              <div className="mt-2 inline-flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                <CheckCircle className="w-3 h-3" />
                {record.paymentStatus === 'paid' ? 'পরিশোধিত (Paid)' : record.paymentStatus}
              </div>
            </div>
          </div>

          {/* Breakdown Grid */}
          <div className="grid grid-cols-2 gap-6 mt-6">
            {/* Earnings */}
            <div className="border border-slate-200 rounded-xl p-4 bg-white">
              <h4 className="font-semibold text-emerald-700 text-sm pb-2 border-b border-emerald-100 flex justify-between">
                <span>আয় ও ভাতাসমূহ (Earnings)</span>
                <span>পরিমাণ</span>
              </h4>
              <div className="divide-y divide-slate-100 text-sm mt-2">
                <div className="py-2 flex justify-between text-slate-700">
                  <span>মূল বেতন (Base Salary):</span>
                  <span className="font-medium">{currency} {record.baseSalary.toLocaleString()}</span>
                </div>
                <div className="py-2 flex justify-between text-slate-700">
                  <span>উপস্থিত দিন ({record.presentDays} দিন):</span>
                  <span className="text-slate-500 text-xs">কার্যকরী</span>
                </div>
                <div className="py-2 flex justify-between text-slate-700">
                  <span>ওভারটাইম ভাতা:</span>
                  <span className="font-medium">{currency} {record.overtimePay.toLocaleString()}</span>
                </div>
                <div className="py-2 flex justify-between text-slate-700">
                  <span>বোনাস / ইনসেন্টিভ:</span>
                  <span className="font-medium">{currency} {record.bonus.toLocaleString()}</span>
                </div>
                <div className="pt-3 flex justify-between font-bold text-slate-900 border-t border-slate-200">
                  <span>মোট আয়:</span>
                  <span>{currency} {(record.baseSalary + record.overtimePay + record.bonus).toLocaleString()}</span>
                </div>
              </div>
            </div>

            {/* Deductions */}
            <div className="border border-slate-200 rounded-xl p-4 bg-white">
              <h4 className="font-semibold text-rose-700 text-sm pb-2 border-b border-rose-100 flex justify-between">
                <span>কর্তনসমূহ (Deductions)</span>
                <span>পরিমাণ</span>
              </h4>
              <div className="divide-y divide-slate-100 text-sm mt-2">
                <div className="py-2 flex justify-between text-slate-700">
                  <span>অগ্রিম ঋণ সমন্বয়:</span>
                  <span className="font-medium text-rose-600">
                    - {currency} {record.advanceDeduction.toLocaleString()}
                  </span>
                </div>
                <div className="py-2 flex justify-between text-slate-700">
                  <span>অনুপস্থিতি / জরিমানা:</span>
                  <span className="font-medium text-rose-600">
                    - {currency} {record.otherDeductions.toLocaleString()}
                  </span>
                </div>
                <div className="pt-10 flex justify-between font-bold text-slate-900 border-t border-slate-200">
                  <span>মোট কর্তন:</span>
                  <span className="text-rose-600">
                    - {currency} {(record.advanceDeduction + record.otherDeductions).toLocaleString()}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Net Amount Banner */}
          <div className="mt-6 p-4 bg-slate-900 text-white rounded-xl flex justify-between items-center">
            <div>
              <p className="text-xs text-slate-400">সর্বমোট প্রদেয় চূড়ান্ত বেতন (Net Payable Amount):</p>
              <p className="text-xs text-slate-300 mt-0.5">কথায়: মোট প্রদেয় বেতন নগদ বা ব্যাংকে পরিশোধ করা হয়েছে।</p>
            </div>
            <div className="text-2xl font-black text-emerald-400">
              {currency} {record.netPayable.toLocaleString()}
            </div>
          </div>

          {/* Signatures */}
          <div className="grid grid-cols-2 gap-8 pt-16 pb-4 mt-8 text-center text-xs text-slate-600">
            <div>
              <div className="border-t border-slate-400 pt-2 w-48 mx-auto">
                কর্মচারীর স্বাক্ষর
              </div>
            </div>
            <div>
              <div className="border-t border-slate-400 pt-2 w-48 mx-auto">
                হিসাবরক্ষক / কর্তৃপক্ষের স্বাক্ষর
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
