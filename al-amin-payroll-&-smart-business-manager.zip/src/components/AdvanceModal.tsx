import React, { useState } from 'react';
import { X, Save, HandCoins } from 'lucide-react';
import type { AdvanceLoan, Employee } from '../types';
import { generateCleanId } from '../services/dbService';

interface AdvanceModalProps {
  advance?: AdvanceLoan | null;
  employees: Employee[];
  userId: string;
  currency: string;
  onSave: (advance: AdvanceLoan) => Promise<void>;
  onClose: () => void;
}

export const AdvanceModal: React.FC<AdvanceModalProps> = ({
  advance,
  employees,
  userId,
  currency,
  onSave,
  onClose,
}) => {
  const [employeeId, setEmployeeId] = useState(advance?.employeeId || (employees[0]?.id || ''));
  const [amount, setAmount] = useState(advance?.amount?.toString() || '');
  const [date, setDate] = useState(advance?.date || new Date().toISOString().split('T')[0]);
  const [reason, setReason] = useState(advance?.reason || '');
  const [status, setStatus] = useState<'unpaid' | 'repaid' | 'deducted'>(
    advance?.status || 'unpaid'
  );
  const [saving, setSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!employeeId) {
      setErrorMsg('কর্মচারী নির্বাচন করুন');
      return;
    }
    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      setErrorMsg('সঠিক অগ্রিম টাকার পরিমাণ দিন');
      return;
    }

    const selectedEmp = employees.find((e) => e.id === employeeId);
    setSaving(true);
    setErrorMsg('');

    try {
      const record: AdvanceLoan = {
        id: advance?.id || generateCleanId('adv'),
        userId,
        employeeId,
        employeeName: selectedEmp?.name || advance?.employeeName || 'Unknown',
        amount: numAmount,
        date: date.slice(0, 20),
        reason: reason.trim().slice(0, 200) || 'বেতন অগ্রিম',
        status,
        createdAt: advance?.createdAt || new Date().toISOString(),
      };

      await onSave(record);
      onClose();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'সংরক্ষণ ব্যর্থ হয়েছে';
      setErrorMsg(msg);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 border border-slate-200 relative my-8">
        <div className="flex justify-between items-center pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-amber-50 text-amber-600 rounded-lg">
              <HandCoins className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-lg text-slate-800">
              {advance ? 'অগ্রিম ঋণ এন্ট্রি সম্পাদনা' : 'নতুন অগ্রিম বেতন / ঋণ প্রদান'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-slate-100 text-slate-400 hover:text-slate-600 rounded-lg transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {errorMsg && (
          <div className="mt-3 p-3 text-xs bg-rose-50 border border-rose-200 text-rose-700 rounded-lg">
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              কর্মচারী নির্বাচন করুন *
            </label>
            <select
              required
              value={employeeId}
              onChange={(e) => setEmployeeId(e.target.value)}
              className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-amber-500 outline-none transition"
            >
              <option value="" disabled>
                কর্মচারী বাছাই করুন
              </option>
              {employees.map((emp) => (
                <option key={emp.id} value={emp.id}>
                  {emp.name} ({emp.designation}) - বেতন: {currency} {emp.monthlySalary.toLocaleString()}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              অগ্রিম টাকার পরিমাণ ({currency}) *
            </label>
            <input
              type="number"
              required
              min="1"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="যেমন: 5000"
              className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none font-bold text-slate-800 transition"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                প্রদানের তারিখ
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none transition"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                পরিশোধের স্ট্যাটাস
              </label>
              <select
                value={status}
                onChange={(e) =>
                  setStatus(e.target.value as 'unpaid' | 'repaid' | 'deducted')
                }
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-amber-500 outline-none transition"
              >
                <option value="unpaid">বকেয়া (Unpaid)</option>
                <option value="repaid">নগদে পরিশোধিত (Repaid)</option>
                <option value="deducted">বেতন থেকে কর্তিত (Deducted)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              কারণ / বিবরণ
            </label>
            <input
              type="text"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="যেমন: জরুরি পারিবারিক খরচ বা বাড়ি যাওয়ার জন্য"
              className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none transition"
            />
          </div>

          <div className="pt-4 flex justify-end gap-2 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-xl transition cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center gap-1.5 px-5 py-2 text-sm font-semibold text-white bg-amber-600 hover:bg-amber-700 rounded-xl shadow-xs transition disabled:opacity-50 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              {saving ? 'সেভ হচ্ছে...' : 'ডাটাবেজে সেভ করুন'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
