import React, { useState } from 'react';
import {
  ReceiptText,
  Calculator,
  Printer,
  CheckCircle2,
  AlertCircle,
  FileText,
  Save,
  Download,
  DollarSign,
} from 'lucide-react';
import type { Employee, AttendanceRecord, PayrollRecord, AdvanceLoan, CompanySetting } from '../types';
import { generateCleanId } from '../services/dbService';
import { PayslipModal } from './PayslipModal';

interface PayrollViewProps {
  employees: Employee[];
  attendanceRecords: AttendanceRecord[];
  payrollRecords: PayrollRecord[];
  advances: AdvanceLoan[];
  settings: CompanySetting;
  userId: string;
  currency: string;
  isBn: boolean;
  onSavePayroll: (record: PayrollRecord) => Promise<void>;
  onDeletePayroll: (payrollId: string) => Promise<void>;
}

export const PayrollView: React.FC<PayrollViewProps> = ({
  employees,
  attendanceRecords,
  payrollRecords,
  advances,
  settings,
  userId,
  currency,
  isBn,
  onSavePayroll,
  onDeletePayroll,
}) => {
  const currentYearMonth = new Date().toISOString().slice(0, 7); // "YYYY-MM"
  const [selectedMonth, setSelectedMonth] = useState(currentYearMonth);
  const [selectedPayslipRecord, setSelectedPayslipRecord] = useState<PayrollRecord | null>(null);
  const [calculating, setCalculating] = useState(false);
  const [savingStatusId, setSavingStatusId] = useState<string | null>(null);

  const activeEmployees = employees.filter((e) => e.status === 'active');

  // Filter payroll records for the selected month
  const monthlyPayrolls = payrollRecords.filter((p) => p.monthYear === selectedMonth);
  const payrollMap = new Map(monthlyPayrolls.map((p) => [p.employeeId, p]));

  // Auto-generate or compute payroll for all active employees for this month
  const handleAutoComputeAll = async () => {
    setCalculating(true);
    try {
      const workingDays = settings.workingDaysPerMonth || 26;
      const hourlyRate = settings.overtimeRatePerHour || 100;

      for (const emp of activeEmployees) {
        // Find attendance in this month for this employee
        const empAttendance = attendanceRecords.filter(
          (a) => a.employeeId === emp.id && a.date.startsWith(selectedMonth)
        );

        let presentDays = 0;
        let overtimeHours = 0;

        empAttendance.forEach((a) => {
          if (a.status === 'present' || a.status === 'late') {
            presentDays += 1;
          } else if (a.status === 'half_day') {
            presentDays += 0.5;
          }
          overtimeHours += a.overtimeHours || 0;
        });

        // If no attendance records logged for the month, assume full month by default or logged days
        const effectiveDays = empAttendance.length > 0 ? presentDays : workingDays;

        // Base salary computation
        const baseSalary = emp.monthlySalary || 0;
        const overtimePay = Math.round(overtimeHours * hourlyRate);

        // Check if employee has unpaid advances
        const empUnpaidAdvances = advances.filter(
          (adv) => adv.employeeId === emp.id && adv.status === 'unpaid'
        );
        const totalAdvanceDue = empUnpaidAdvances.reduce((acc, curr) => acc + (curr.amount || 0), 0);

        // Deduct advance up to a reasonable cap (e.g. 50% of salary or full if smaller)
        const advanceDeduction = Math.min(totalAdvanceDue, Math.round(baseSalary * 0.5));

        const existingRecord = payrollMap.get(emp.id);
        const bonus = existingRecord?.bonus || 0;
        const otherDeductions = existingRecord?.otherDeductions || 0;

        const netPayable = Math.max(
          0,
          baseSalary + overtimePay + bonus - advanceDeduction - otherDeductions
        );

        const newRecord: PayrollRecord = {
          id: existingRecord?.id || generateCleanId('pay'),
          userId,
          employeeId: emp.id,
          employeeName: emp.name,
          monthYear: selectedMonth,
          baseSalary,
          presentDays: effectiveDays,
          absentDays: Math.max(0, workingDays - effectiveDays),
          overtimePay,
          bonus,
          advanceDeduction,
          otherDeductions,
          netPayable,
          paymentStatus: existingRecord?.paymentStatus || 'pending',
          paidAmount: existingRecord?.paymentStatus === 'paid' ? netPayable : 0,
          paymentMethod: emp.paymentMethod || 'cash',
          paymentDate: existingRecord?.paymentDate || new Date().toISOString().split('T')[0],
          notes: existingRecord?.notes || '',
          createdAt: existingRecord?.createdAt || new Date().toISOString(),
        };

        await onSavePayroll(newRecord);
      }
    } finally {
      setCalculating(false);
    }
  };

  const handleUpdatePaymentStatus = async (
    record: PayrollRecord,
    status: 'paid' | 'partial' | 'pending'
  ) => {
    setSavingStatusId(record.id);
    try {
      const updated: PayrollRecord = {
        ...record,
        paymentStatus: status,
        paidAmount: status === 'paid' ? record.netPayable : record.paidAmount,
        paymentDate: new Date().toISOString().split('T')[0],
      };
      await onSavePayroll(updated);
    } finally {
      setSavingStatusId(null);
    }
  };

  const totalMonthlyNet = monthlyPayrolls.reduce((acc, curr) => acc + curr.netPayable, 0);
  const totalPaid = monthlyPayrolls
    .filter((p) => p.paymentStatus === 'paid')
    .reduce((acc, curr) => acc + curr.netPayable, 0);
  const totalPending = totalMonthlyNet - totalPaid;

  return (
    <div className="space-y-6">
      {/* Header and Controls */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <ReceiptText className="w-5 h-5 text-emerald-600" />
            {isBn ? 'মাসিক বেতন বিবরণী ও পে-স্লিপ' : 'Monthly Payroll & Payslips'}
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {isBn
              ? 'হাজিরা ও অগ্রিম কর্তন সমন্বয় করে চূড়ান্ত বেতন শিট স্বয়ংক্রিয়ভাবে তৈরি করুন'
              : 'Auto-compute salary based on attendance, overtime & advance deductions'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          {/* Month Selector */}
          <div className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200">
            <span className="text-xs font-semibold text-slate-500">{isBn ? 'মাস:' : 'Month:'}</span>
            <input
              type="month"
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="bg-transparent text-xs sm:text-sm font-semibold text-slate-800 outline-none cursor-pointer"
            />
          </div>

          {/* Auto Calculate Button */}
          <button
            onClick={handleAutoComputeAll}
            disabled={calculating}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs sm:text-sm rounded-xl shadow-xs transition disabled:opacity-50 cursor-pointer"
          >
            <Calculator className="w-4 h-4" />
            {calculating
              ? isBn
                ? 'হিসাব হচ্ছে...'
                : 'Computing...'
              : isBn
              ? 'বেতন শিট তৈরি / রিফ্রেশ করুন'
              : 'Compute Payroll'}
          </button>
        </div>
      </div>

      {/* Monthly Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs">
          <p className="text-xs font-semibold text-slate-500 uppercase">{isBn ? 'মোট প্রদেয় বেতন' : 'Total Net Payroll'}</p>
          <p className="text-2xl font-bold text-slate-900 mt-1">
            {currency} {totalMonthlyNet.toLocaleString()}
          </p>
          <p className="text-xs text-slate-500 mt-1">
            {monthlyPayrolls.length} {isBn ? 'জনের জন্য প্রক্রিয়াকৃত' : 'processed staff'}
          </p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-emerald-200 shadow-xs bg-emerald-50/20">
          <p className="text-xs font-semibold text-emerald-700 uppercase">{isBn ? 'পরিশোধিত বেতন (Paid)' : 'Total Paid'}</p>
          <p className="text-2xl font-bold text-emerald-600 mt-1">
            {currency} {totalPaid.toLocaleString()}
          </p>
          <p className="text-xs text-emerald-700 mt-1 flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            {isBn ? 'ইতিমধ্যে বিতরণকৃত' : 'Disbursed'}
          </p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-amber-200 shadow-xs bg-amber-50/20">
          <p className="text-xs font-semibold text-amber-700 uppercase">{isBn ? 'বকেয়া বেতন (Pending)' : 'Pending Disbursal'}</p>
          <p className="text-2xl font-bold text-amber-600 mt-1">
            {currency} {totalPending.toLocaleString()}
          </p>
          <p className="text-xs text-amber-700 mt-1 flex items-center gap-1">
            <AlertCircle className="w-3.5 h-3.5" />
            {isBn ? 'পরিশোধের অপেক্ষায়' : 'Awaiting payment'}
          </p>
        </div>
      </div>

      {/* Payroll Table */}
      {monthlyPayrolls.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
          <ReceiptText className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-700">
            {isBn
              ? `${selectedMonth} মাসের কোনো বেতন শিট তৈরি করা হয়নি`
              : `No payroll generated for ${selectedMonth}`}
          </h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            {isBn
              ? 'উপরের "বেতন শিট তৈরি / রিফ্রেশ করুন" বাটনে ক্লিক করলে সক্রিয় সকল কর্মচারীর জন্য বেতন শিট ও পে-স্লিপ তৈরি হয়ে ক্লাউডে সংরক্ষিত হবে।'
              : 'Click "Compute Payroll" above to auto-generate salary breakdown for this month.'}
          </p>
          <button
            onClick={handleAutoComputeAll}
            className="mt-4 inline-flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs sm:text-sm rounded-xl transition cursor-pointer"
          >
            <Calculator className="w-4 h-4" />
            {isBn ? 'এই মাসের বেতন হিসাব করুন' : 'Generate This Month Payroll'}
          </button>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-slate-500 text-xs uppercase font-semibold border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">{isBn ? 'কর্মচারী' : 'Employee'}</th>
                  <th className="py-3 px-4">{isBn ? 'মূল বেতন' : 'Base Salary'}</th>
                  <th className="py-3 px-4">{isBn ? 'ওভারটাইম' : 'Overtime'}</th>
                  <th className="py-3 px-4">{isBn ? 'অগ্রিম কর্তন' : 'Advance Cut'}</th>
                  <th className="py-3 px-4">{isBn ? 'চূড়ান্ত প্রদেয় (Net)' : 'Net Payable'}</th>
                  <th className="py-3 px-4">{isBn ? 'পেমেন্ট অবস্থা' : 'Payment Status'}</th>
                  <th className="py-3 px-4 text-right">{isBn ? 'পে-স্লিপ' : 'Payslip'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {monthlyPayrolls.map((record) => {
                  const emp = employees.find((e) => e.id === record.employeeId);
                  const isUpdating = savingStatusId === record.id;

                  return (
                    <tr key={record.id} className="hover:bg-slate-50/70 transition">
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-900">{record.employeeName}</div>
                        <div className="text-xs text-slate-400 capitalize">
                          {emp?.designation || 'Staff'} • {record.paymentMethod}
                        </div>
                      </td>

                      <td className="py-3.5 px-4 font-mono text-xs text-slate-700">
                        {currency} {record.baseSalary.toLocaleString()}
                      </td>

                      <td className="py-3.5 px-4 font-mono text-xs text-slate-700">
                        +{currency} {record.overtimePay.toLocaleString()}
                      </td>

                      <td className="py-3.5 px-4 font-mono text-xs text-rose-600">
                        {record.advanceDeduction > 0
                          ? `-${currency} ${record.advanceDeduction.toLocaleString()}`
                          : '-'}
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="font-black text-slate-900 text-sm font-mono">
                          {currency} {record.netPayable.toLocaleString()}
                        </span>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-1.5">
                          <select
                            value={record.paymentStatus}
                            onChange={(e) =>
                              handleUpdatePaymentStatus(
                                record,
                                e.target.value as 'paid' | 'partial' | 'pending'
                              )
                            }
                            disabled={isUpdating}
                            className={`text-xs font-semibold rounded-lg px-2.5 py-1 border outline-none cursor-pointer ${
                              record.paymentStatus === 'paid'
                                ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                                : record.paymentStatus === 'partial'
                                ? 'bg-orange-50 text-orange-700 border-orange-300'
                                : 'bg-amber-50 text-amber-700 border-amber-300'
                            }`}
                          >
                            <option value="paid">{isBn ? 'পরিশোধিত (Paid)' : 'Paid'}</option>
                            <option value="partial">{isBn ? 'আংশিক (Partial)' : 'Partial'}</option>
                            <option value="pending">{isBn ? 'বকেয়া (Pending)' : 'Pending'}</option>
                          </select>
                        </div>
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => setSelectedPayslipRecord(record)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg transition cursor-pointer"
                        >
                          <FileText className="w-3.5 h-3.5" />
                          <span>{isBn ? 'পে-স্লিপ' : 'Slip'}</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Payslip Modal View */}
      {selectedPayslipRecord && (
        <PayslipModal
          record={selectedPayslipRecord}
          employee={employees.find((e) => e.id === selectedPayslipRecord.employeeId)}
          settings={settings}
          currency={currency}
          onClose={() => setSelectedPayslipRecord(null)}
        />
      )}
    </div>
  );
};
