import React, { useState } from 'react';
import { X, Save, UserPlus, Phone, Briefcase, DollarSign } from 'lucide-react';
import type { Employee } from '../types';
import { generateCleanId } from '../services/dbService';

interface EmployeeModalProps {
  employee?: Employee | null;
  userId: string;
  onSave: (employee: Employee) => Promise<void>;
  onClose: () => void;
}

export const EmployeeModal: React.FC<EmployeeModalProps> = ({
  employee,
  userId,
  onSave,
  onClose,
}) => {
  const [employeeCode, setEmployeeCode] = useState(
    employee?.employeeCode || `EMP-${Math.floor(100 + Math.random() * 900)}`
  );
  const [name, setName] = useState(employee?.name || '');
  const [phone, setPhone] = useState(employee?.phone || '');
  const [designation, setDesignation] = useState(employee?.designation || '');
  const [department, setDepartment] = useState(employee?.department || '');
  const [monthlySalary, setMonthlySalary] = useState(employee?.monthlySalary?.toString() || '');
  const [salaryType, setSalaryType] = useState<'monthly' | 'daily'>(employee?.salaryType || 'monthly');
  const [joiningDate, setJoiningDate] = useState(
    employee?.joiningDate || new Date().toISOString().split('T')[0]
  );
  const [status, setStatus] = useState<'active' | 'inactive'>(employee?.status || 'active');
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'bKash' | 'Nagad' | 'bank'>(
    employee?.paymentMethod || 'cash'
  );
  const [accountDetails, setAccountDetails] = useState(employee?.accountDetails || '');
  const [saving, setSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setErrorMsg('কর্মচারীর নাম অবশ্যই দিতে হবে');
      return;
    }
    const salaryVal = parseFloat(monthlySalary);
    if (isNaN(salaryVal) || salaryVal < 0) {
      setErrorMsg('সঠিক বেতন দিন');
      return;
    }

    setSaving(true);
    setErrorMsg('');

    try {
      const record: Employee = {
        id: employee?.id || generateCleanId('emp'),
        userId,
        employeeCode: employeeCode.trim().toUpperCase() || 'EMP-001',
        name: name.trim().slice(0, 100),
        phone: phone.trim().slice(0, 20),
        designation: designation.trim().slice(0, 100) || 'Staff',
        department: department.trim().slice(0, 100) || 'General',
        monthlySalary: salaryVal,
        salaryType,
        joiningDate: joiningDate.slice(0, 20),
        status,
        paymentMethod,
        accountDetails: accountDetails.trim().slice(0, 100),
        createdAt: employee?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await onSave(record);
      onClose();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'সংরক্ষণ করতে সমস্যা হয়েছে';
      setErrorMsg(msg);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-6 border border-slate-200 relative my-8">
        <div className="flex justify-between items-center pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
              <UserPlus className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-lg text-slate-800">
              {employee ? 'কর্মচারীর তথ্য সম্পাদনা' : 'নতুন কর্মচারী নিবন্ধন'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-slate-100 text-slate-400 hover:text-slate-600 rounded-lg transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {errorMsg && (
          <div className="mt-3 p-3 text-xs bg-rose-50 border border-rose-200 text-rose-700 rounded-lg">
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                কর্মচারী আইডি (ID) *
              </label>
              <input
                type="text"
                required
                value={employeeCode}
                onChange={(e) => setEmployeeCode(e.target.value)}
                placeholder="EMP-001"
                className="w-full px-3 py-2 text-sm font-mono font-bold border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none uppercase transition"
              />
            </div>
            <div className="col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                কর্মচারীর নাম (Full Name) *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="যেমন: মোঃ আল-আমিন"
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
                <Phone className="w-3.5 h-3.5 text-slate-400" />
                মোবাইল নম্বর
              </label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="017xxxxxxxx"
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
                <Briefcase className="w-3.5 h-3.5 text-slate-400" />
                পদবী (Designation)
              </label>
              <input
                type="text"
                value={designation}
                onChange={(e) => setDesignation(e.target.value)}
                placeholder="ম্যানেজার / অপারেটর"
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                বিভাগ / শাখা
              </label>
              <input
                type="text"
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                placeholder="প্রোডাকশন / অফিস"
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                বেতনের ধরন
              </label>
              <select
                value={salaryType}
                onChange={(e) => setSalaryType(e.target.value as 'monthly' | 'daily')}
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-blue-500 outline-none transition"
              >
                <option value="monthly">মাসিক বেতন (Monthly)</option>
                <option value="daily">দৈনিক মজুরি (Daily)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
                <DollarSign className="w-3.5 h-3.5 text-slate-400" />
                মূল বেতন / মজুরি (৳) *
              </label>
              <input
                type="number"
                required
                min="0"
                value={monthlySalary}
                onChange={(e) => setMonthlySalary(e.target.value)}
                placeholder="যেমন: 25000"
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition font-semibold text-slate-800"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                যোগদানের তারিখ
              </label>
              <input
                type="date"
                value={joiningDate}
                onChange={(e) => setJoiningDate(e.target.value)}
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                পেমেন্ট মেথড
              </label>
              <select
                value={paymentMethod}
                onChange={(e) =>
                  setPaymentMethod(e.target.value as 'cash' | 'bKash' | 'Nagad' | 'bank')
                }
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-blue-500 outline-none transition"
              >
                <option value="cash">নগদ (Cash)</option>
                <option value="bKash">বিকাশ (bKash)</option>
                <option value="Nagad">নগদ (Nagad)</option>
                <option value="bank">ব্যাংক ট্রান্সফার (Bank)</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                স্ট্যাটাস
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as 'active' | 'inactive')}
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-blue-500 outline-none transition"
              >
                <option value="active">সক্রিয় (Active)</option>
                <option value="inactive">নিষ্ক্রিয় (Inactive)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              অ্যাকাউন্ট / ওয়ালেট নম্বর (ঐচ্ছিক)
            </label>
            <input
              type="text"
              value={accountDetails}
              onChange={(e) => setAccountDetails(e.target.value)}
              placeholder="যেমন: বিকাশ পার্সোনাল 017xxxxxxxx বা ব্যাংক হিসাব নং"
              className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
            />
          </div>

          <div className="pt-4 flex justify-end gap-2 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-xl transition cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center gap-1.5 px-5 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition disabled:opacity-50 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              {saving ? 'সংরক্ষণ হচ্ছে...' : 'ডাটাবেজে সেভ করুন'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
