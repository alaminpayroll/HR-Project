import React, { useState } from 'react';
import {
  CalendarCheck2,
  Check,
  CheckCheck,
  Clock,
  Sparkles,
  Calendar,
  Save,
} from 'lucide-react';
import type { Employee, AttendanceRecord } from '../types';
import { generateCleanId } from '../services/dbService';

interface AttendanceViewProps {
  employees: Employee[];
  attendanceRecords: AttendanceRecord[];
  userId: string;
  isBn: boolean;
  onSaveAttendance: (record: AttendanceRecord) => Promise<void>;
}

export const AttendanceView: React.FC<AttendanceViewProps> = ({
  employees,
  attendanceRecords,
  userId,
  isBn,
  onSaveAttendance,
}) => {
  const [selectedDate, setSelectedDate] = useState(
    new Date().toISOString().split('T')[0]
  );
  const [savingMap, setSavingMap] = useState<Record<string, boolean>>({});
  const [savedSuccessMap, setSavedSuccessMap] = useState<Record<string, boolean>>({});

  const activeEmployees = employees.filter((e) => e.status === 'active');

  // Find attendance records for the selected date
  const recordsForDate = attendanceRecords.filter((a) => a.date === selectedDate);
  const recordMap = new Map(recordsForDate.map((r) => [r.employeeId, r]));

  const getRecordForEmployee = (empId: string): Partial<AttendanceRecord> => {
    return recordMap.get(empId) || {
      employeeId: empId,
      date: selectedDate,
      status: 'present',
      overtimeHours: 0,
      note: '',
    };
  };

  const handleUpdateStatus = async (
    emp: Employee,
    status: 'present' | 'absent' | 'late' | 'half_day' | 'leave'
  ) => {
    const existing = recordMap.get(emp.id);
    const updated: AttendanceRecord = {
      id: existing?.id || generateCleanId('att'),
      userId,
      employeeId: emp.id,
      employeeName: emp.name,
      date: selectedDate,
      status,
      overtimeHours: existing?.overtimeHours || 0,
      note: existing?.note || '',
      createdAt: existing?.createdAt || new Date().toISOString(),
    };

    setSavingMap((prev) => ({ ...prev, [emp.id]: true }));
    try {
      await onSaveAttendance(updated);
      setSavedSuccessMap((prev) => ({ ...prev, [emp.id]: true }));
      setTimeout(() => {
        setSavedSuccessMap((prev) => ({ ...prev, [emp.id]: false }));
      }, 2000);
    } finally {
      setSavingMap((prev) => ({ ...prev, [emp.id]: false }));
    }
  };

  const handleUpdateOvertime = async (emp: Employee, hours: number) => {
    const existing = recordMap.get(emp.id);
    const updated: AttendanceRecord = {
      id: existing?.id || generateCleanId('att'),
      userId,
      employeeId: emp.id,
      employeeName: emp.name,
      date: selectedDate,
      status: existing?.status || 'present',
      overtimeHours: Math.max(0, hours),
      note: existing?.note || '',
      createdAt: existing?.createdAt || new Date().toISOString(),
    };

    setSavingMap((prev) => ({ ...prev, [emp.id]: true }));
    try {
      await onSaveAttendance(updated);
      setSavedSuccessMap((prev) => ({ ...prev, [emp.id]: true }));
      setTimeout(() => {
        setSavedSuccessMap((prev) => ({ ...prev, [emp.id]: false }));
      }, 2000);
    } finally {
      setSavingMap((prev) => ({ ...prev, [emp.id]: false }));
    }
  };

  const handleMarkAllPresent = async () => {
    for (const emp of activeEmployees) {
      const existing = recordMap.get(emp.id);
      const updated: AttendanceRecord = {
        id: existing?.id || generateCleanId('att'),
        userId,
        employeeId: emp.id,
        employeeName: emp.name,
        date: selectedDate,
        status: 'present',
        overtimeHours: existing?.overtimeHours || 0,
        note: existing?.note || '',
        createdAt: existing?.createdAt || new Date().toISOString(),
      };
      await onSaveAttendance(updated);
    }
  };

  const presentCount = recordsForDate.filter(
    (r) => r.status === 'present' || r.status === 'late' || r.status === 'half_day'
  ).length;
  const absentCount = recordsForDate.filter((r) => r.status === 'absent').length;
  const leaveCount = recordsForDate.filter((r) => r.status === 'leave').length;

  return (
    <div className="space-y-6">
      {/* Date Header & Action Bar */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <CalendarCheck2 className="w-5 h-5 text-indigo-600" />
            {isBn ? 'দৈনিক উপস্থিতি ও ওভারটাইম রেজিস্টার' : 'Daily Attendance & Overtime'}
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {isBn
              ? 'প্রতিদিনের হাজিরা সরাসরি ক্লাউড ডাটাবেজে সংরক্ষণ করা হয়'
              : 'Attendance logs persist directly to Firebase Cloud Firestore'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          {/* Date Picker */}
          <div className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200">
            <Calendar className="w-4 h-4 text-slate-500" />
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="bg-transparent text-xs sm:text-sm font-semibold text-slate-800 outline-none cursor-pointer"
            />
          </div>

          {/* Quick Mark All Present */}
          <button
            onClick={handleMarkAllPresent}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs sm:text-sm rounded-xl shadow-xs transition cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            {isBn ? 'সবাইকে উপস্থিত মার্ক করুন' : 'Mark All Present'}
          </button>
        </div>
      </div>

      {/* Daily Attendance Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs">
          <p className="text-xs text-slate-500 font-semibold">{isBn ? 'মোট সক্রিয়' : 'Active Staff'}</p>
          <p className="text-xl font-bold text-slate-900 mt-1">{activeEmployees.length} {isBn ? 'জন' : ''}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-emerald-200 shadow-xs bg-emerald-50/20">
          <p className="text-xs text-emerald-700 font-semibold">{isBn ? 'উপস্থিত' : 'Present'}</p>
          <p className="text-xl font-bold text-emerald-600 mt-1">{presentCount} {isBn ? 'জন' : ''}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-rose-200 shadow-xs bg-rose-50/20">
          <p className="text-xs text-rose-700 font-semibold">{isBn ? 'অনুপস্থিত' : 'Absent'}</p>
          <p className="text-xl font-bold text-rose-600 mt-1">{absentCount} {isBn ? 'জন' : ''}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-blue-200 shadow-xs bg-blue-50/20">
          <p className="text-xs text-blue-700 font-semibold">{isBn ? 'ছুটি / অন্যান্য' : 'Leave / Other'}</p>
          <p className="text-xl font-bold text-blue-600 mt-1">{leaveCount} {isBn ? 'জন' : ''}</p>
        </div>
      </div>

      {/* Attendance Grid */}
      {activeEmployees.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
          <CalendarCheck2 className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-700">
            {isBn ? 'কোনো সক্রিয় কর্মচারী নেই' : 'No active employees'}
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            {isBn
              ? 'প্রথমে কর্মচারী তালিকা থেকে নতুন কর্মচারী নিবন্ধন করুন।'
              : 'Add active employees in the Employee tab first.'}
          </p>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-slate-500 text-xs uppercase font-semibold border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">{isBn ? 'কর্মচারী' : 'Employee'}</th>
                  <th className="py-3 px-4">{isBn ? 'উপস্থিতি স্ট্যাটাস' : 'Attendance Status'}</th>
                  <th className="py-3 px-4">{isBn ? 'ওভারটাইম (ঘণ্টা)' : 'Overtime'}</th>
                  <th className="py-3 px-4 text-right">{isBn ? 'ডাটাবেজ স্ট্যাটাস' : 'Save Status'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {activeEmployees.map((emp) => {
                  const currentRec = getRecordForEmployee(emp.id);
                  const isSaving = savingMap[emp.id];
                  const isSaved = savedSuccessMap[emp.id];
                  const status = currentRec.status || 'present';

                  return (
                    <tr key={emp.id} className="hover:bg-slate-50/70 transition">
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900">{emp.name}</div>
                        <div className="text-xs text-slate-400">
                          {emp.designation} • {emp.department}
                        </div>
                      </td>

                      {/* Status Selector Pills */}
                      <td className="py-3 px-4">
                        <div className="flex flex-wrap gap-1.5">
                          {/* Present */}
                          <button
                            onClick={() => handleUpdateStatus(emp, 'present')}
                            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                              status === 'present'
                                ? 'bg-emerald-600 text-white shadow-xs'
                                : 'bg-slate-100 text-slate-600 hover:bg-emerald-50 hover:text-emerald-700'
                            }`}
                          >
                            {isBn ? 'উপস্থিত' : 'Present'}
                          </button>

                          {/* Absent */}
                          <button
                            onClick={() => handleUpdateStatus(emp, 'absent')}
                            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                              status === 'absent'
                                ? 'bg-rose-600 text-white shadow-xs'
                                : 'bg-slate-100 text-slate-600 hover:bg-rose-50 hover:text-rose-700'
                            }`}
                          >
                            {isBn ? 'অনুপস্থিত' : 'Absent'}
                          </button>

                          {/* Late */}
                          <button
                            onClick={() => handleUpdateStatus(emp, 'late')}
                            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                              status === 'late'
                                ? 'bg-amber-500 text-white shadow-xs'
                                : 'bg-slate-100 text-slate-600 hover:bg-amber-50 hover:text-amber-700'
                            }`}
                          >
                            {isBn ? 'দেরি' : 'Late'}
                          </button>

                          {/* Half Day */}
                          <button
                            onClick={() => handleUpdateStatus(emp, 'half_day')}
                            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                              status === 'half_day'
                                ? 'bg-orange-500 text-white shadow-xs'
                                : 'bg-slate-100 text-slate-600 hover:bg-orange-50 hover:text-orange-700'
                            }`}
                          >
                            {isBn ? 'অর্ধদিবস' : 'Half Day'}
                          </button>

                          {/* Leave */}
                          <button
                            onClick={() => handleUpdateStatus(emp, 'leave')}
                            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                              status === 'leave'
                                ? 'bg-blue-600 text-white shadow-xs'
                                : 'bg-slate-100 text-slate-600 hover:bg-blue-50 hover:text-blue-700'
                            }`}
                          >
                            {isBn ? 'ছুটি' : 'Leave'}
                          </button>
                        </div>
                      </td>

                      {/* Overtime Input */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5 text-slate-400" />
                          <input
                            type="number"
                            min="0"
                            step="0.5"
                            value={currentRec.overtimeHours ?? 0}
                            onChange={(e) =>
                              handleUpdateOvertime(emp, parseFloat(e.target.value) || 0)
                            }
                            className="w-16 px-2 py-1 text-xs border border-slate-200 rounded-lg text-center font-semibold text-slate-800 outline-none focus:ring-1 focus:ring-indigo-500"
                          />
                          <span className="text-xs text-slate-500">{isBn ? 'ঘণ্টা' : 'hrs'}</span>
                        </div>
                      </td>

                      {/* Auto-save Status */}
                      <td className="py-3 px-4 text-right">
                        {isSaving ? (
                          <span className="inline-flex items-center gap-1 text-xs text-blue-600 font-medium">
                            <Save className="w-3 h-3 animate-spin" />
                            {isBn ? 'সেভ হচ্ছে...' : 'Saving...'}
                          </span>
                        ) : isSaved ? (
                          <span className="inline-flex items-center gap-1 text-xs text-emerald-600 font-semibold bg-emerald-50 px-2 py-0.5 rounded-md">
                            <CheckCheck className="w-3.5 h-3.5" />
                            {isBn ? 'সেভ হয়েছে' : 'Saved'}
                          </span>
                        ) : (
                          <span className="text-xs text-slate-400 font-mono">
                            {isBn ? 'সিঙ্কড' : 'Synced'}
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
