import React, { useState } from 'react';
import {
  X,
  Share2,
  Copy,
  Check,
  ExternalLink,
  Globe,
  QrCode,
  ShieldCheck,
  MessageCircle,
  Users,
} from 'lucide-react';
import { CompanyLogo } from './CompanyLogo';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  isBn: boolean;
}

export const PUBLIC_APP_URL =
  'https://ais-pre-4ydtz5k2k7amzhph4jlvnk-115995763952.asia-southeast1.run.app';

export const ShareModal: React.FC<ShareModalProps> = ({
  isOpen,
  onClose,
  isBn,
}) => {
  const [copied, setCopied] = useState(false);
  const [showQr, setShowQr] = useState(false);

  if (!isOpen) return null;

  const handleCopy = async () => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(PUBLIC_APP_URL);
      } else {
        const input = document.createElement('input');
        input.value = PUBLIC_APP_URL;
        document.body.appendChild(input);
        input.select();
        document.execCommand('copy');
        document.body.removeChild(input);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    } catch (err) {
      console.error('Failed to copy', err);
    }
  };

  const qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(
    PUBLIC_APP_URL
  )}&margin=10`;

  const whatsappShareText = encodeURIComponent(
    `Progress Apparels Bangladesh Ltd. - Employee Leave Portal:\n${PUBLIC_APP_URL}`
  );

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div
        className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 relative animate-in fade-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full transition cursor-pointer"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-5">
          <div className="w-12 h-12 rounded-xl bg-rose-50 border border-rose-200 flex items-center justify-center shrink-0">
            <Share2 className="w-6 h-6 text-rose-600" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-900">
              {isBn ? 'সবার সাথে শেয়ার করার পাবলিক লিংক' : 'Public Link for All Users'}
            </h3>
            <p className="text-xs text-slate-500">
              Progress Apparels Bangladesh Ltd. • Leave Portal
            </p>
          </div>
        </div>

        {/* Explanation Alert: Why link was not opening and how to activate */}
        <div className="mb-5 p-4 bg-amber-50/90 border border-amber-300 rounded-xl text-xs text-amber-950 leading-relaxed shadow-xs">
          <p className="font-bold flex items-center gap-1.5 mb-1.5 text-amber-950 text-sm">
            <Users className="w-4 h-4 text-amber-700" />
            {isBn ? 'অন্যদের লিংক ওপেন না হওয়ার কারণ ও সমাধান:' : 'Why link did not open for others & solution:'}
          </p>
          <div className="space-y-1.5 text-amber-900">
            <p>
              {isBn
                ? '১. আপনি যদি ব্রাউজারের অ্যাড্রেস বার থেকে সরাসরি লিংক শেয়ার করে থাকেন (যাতে ais-dev থাকে), তবে গুগল ক্লাউডের সুরক্ষার কারণে অন্য কেউ ঢুকতে পারবে না (Access Denied দেখাবে)।'
                : '1. If you shared the link directly from your browser bar (ais-dev), Google Cloud restricts it to your personal Google account only.'}
            </p>
            <p className="font-semibold text-rose-800">
              {isBn
                ? '২. সবাইকে ওপেন করার অনুমতি দিতে: এই স্ক্রিনের একদম উপরে-ডানপাশে (Top-Right) থাকা AI Studio-র "Share" বাটনে ক্লিক করে শেয়ার নিশ্চিত করুন।'
                : '2. To allow everyone access: Click the "Share" button at the top-right corner of the AI Studio window to activate the public preview.'}
            </p>
            <p>
              {isBn
                ? '৩. এরপর নিচের পাবলিক লিংকটি কপি করে কর্মচারীদের বা ম্যানেজমেন্টকে পাঠিয়ে দিন — সবাই দেখতে পাবেন!'
                : '3. Then copy the public link below to share with employees or management!'}
            </p>
          </div>
        </div>

        {/* The Public Link Box */}
        <div className="mb-5">
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
            {isBn ? 'সবার জন্য উন্মুক্ত পোর্টাল লিংক:' : 'Public Portal URL:'}
          </label>
          <div className="flex items-center gap-2 p-2 bg-slate-50 border border-slate-300 rounded-xl">
            <Globe className="w-4 h-4 text-slate-400 ml-1 shrink-0" />
            <input
              type="text"
              readOnly
              value={PUBLIC_APP_URL}
              className="flex-1 bg-transparent text-xs text-slate-800 font-mono outline-hidden select-all"
              onClick={(e) => (e.target as HTMLInputElement).select()}
            />
            <button
              onClick={handleCopy}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg transition shadow-xs cursor-pointer ${
                copied
                  ? 'bg-emerald-600 text-white'
                  : 'bg-rose-600 hover:bg-rose-700 text-white'
              }`}
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>{isBn ? 'কপি হয়েছে!' : 'Copied!'}</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>{isBn ? 'কপি করুন' : 'Copy'}</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Quick Share Actions */}
        <div className="grid grid-cols-2 gap-3 mb-5">
          {/* WhatsApp Direct Share */}
          <a
            href={`https://wa.me/?text=${whatsappShareText}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 px-3 py-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-bold transition"
          >
            <MessageCircle className="w-4 h-4 text-emerald-600" />
            <span>{isBn ? 'WhatsApp এ পাঠান' : 'Share on WhatsApp'}</span>
          </a>

          {/* QR Code Toggle */}
          <button
            onClick={() => setShowQr(!showQr)}
            className="flex items-center justify-center gap-2 px-3 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 rounded-xl text-xs font-bold transition cursor-pointer"
          >
            <QrCode className="w-4 h-4 text-slate-600" />
            <span>{showQr ? (isBn ? 'QR লুকান' : 'Hide QR') : (isBn ? 'মোবাইল QR কোড' : 'Show QR')}</span>
          </button>
        </div>

        {/* QR Code Container (Conditional) */}
        {showQr && (
          <div className="mb-5 p-4 bg-slate-50 border border-slate-200 rounded-xl flex flex-col items-center justify-center text-center">
            <img
              src={qrImageUrl}
              alt="Public Leave Portal QR Code"
              className="w-44 h-44 rounded-lg shadow-xs bg-white p-2 border border-slate-200"
            />
            <p className="text-xs text-slate-500 mt-2">
              {isBn
                ? 'কর্মচারীরা মোবাইলের ক্যামেরা দিয়ে স্ক্যান করে সরাসরি ছুটির হিসাব দেখতে পারবেন।'
                : 'Employees can scan this QR code with their mobile cameras to view their leave status.'}
            </p>
          </div>
        )}

        {/* Direct Open in New Tab */}
        <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>{isBn ? 'সবার জন্য ভিউ-অনলি মোডে উন্মুক্ত' : 'View-only mode for general users'}</span>
          </div>
          <a
            href={PUBLIC_APP_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-xs font-semibold text-rose-600 hover:text-rose-800"
          >
            <span>{isBn ? 'লিংকটি টেস্ট করুন' : 'Test Public Link'}</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>
    </div>
  );
};
