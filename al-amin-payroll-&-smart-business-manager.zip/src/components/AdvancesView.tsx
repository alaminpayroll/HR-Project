import React, { useState } from 'react';
import {
  HandCoins,
  Plus,
  CheckCircle2,
  Clock,
  Trash2,
  Calendar,
  AlertCircle,
} from 'lucide-react';
import type { AdvanceLoan, Employee } from '../types';

interface AdvancesViewProps {
  advances: AdvanceLoan[];
  employees: Employee[];
  currency: string;
  isBn: boolean;
  onOpenAdvanceModal: () => void;
  onUpdateStatus: (advance: AdvanceLoan, status: 'unpaid' | 'repaid' | 'deducted') => Promise<void>;
  onDeleteAdvance: (id: string) => Promise<void>;
}

export const AdvancesView: React.FC<AdvancesViewProps> = ({
  advances,
  employees,
  currency,
  isBn,
  onOpenAdvanceModal,
  onUpdateStatus,
  onDeleteAdvance,
}) => {
  const [filterStatus, setFilterStatus] = useState<'all' | 'unpaid' | 'repaid' | 'deducted'>('all');
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const filtered = advances.filter((adv) => {
    if (filterStatus === 'all') return true;
    return adv.status === filterStatus;
  });

  const totalOutstanding = advances
    .filter((a) => a.status === 'unpaid')
    .reduce((acc, curr) => acc + (curr.amount || 0), 0);

  const totalRepaidOrDeducted = advances
    .filter((a) => a.status === 'repaid' || a.status === 'deducted')
    .reduce((acc, curr) => acc + (curr.amount || 0), 0);

  const handleDelete = async (id: string, empName: string, amount: number) => {
    const text = isBn
      ? `আপনি কি '${empName}'-কে দেওয়া ${currency} ${amount} এর অগ্রিম ঋণ রেকর্ড মুছে ফেলতে চান?`
      : `Delete advance record for ${empName} (${currency} ${amount})?`;

    if (window.confirm(text)) {
      setDeletingId(id);
      try {
        await onDeleteAdvance(id);
      } finally {
        setDeletingId(null);
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <HandCoins className="w-5 h-5 text-amber-600" />
            {isBn ? 'অগ্রিম বেতন ও কর্মচারী ঋণ ট্র্যাকার' : 'Salary Advances & Loans'}
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {isBn
              ? 'কর্মচারীদের দেওয়া অগ্রিম টাকা স্বয়ংক্রিয়ভাবে মাসিক বেতন শিটে সমন্বয় করা যায়'
              : 'Track loans & advances to auto-deduct during monthly payroll runs'}
          </p>
        </div>

        <button
          onClick={onOpenAdvanceModal}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-semibold text-xs sm:text-sm rounded-xl shadow-xs transition cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          {isBn ? '+ নতুন অগ্রিম এন্ট্রি' : '+ Issue Advance'}
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-amber-200 shadow-xs bg-amber-50/20">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-semibold text-amber-700 uppercase tracking-wider">
                {isBn ? 'মোট বকেয়া অগ্রিম (Unpaid)' : 'Total Outstanding Advances'}
              </p>
              <h3 className="text-2xl font-bold text-amber-700 mt-1">
                {currency} {totalOutstanding.toLocaleString()}
              </h3>
              <p className="text-xs text-amber-600 mt-1 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                {isBn ? 'বেতন থেকে সমন্বয়যোগ্য' : 'Eligible for salary deduction'}
              </p>
            </div>
            <div className="p-3 bg-amber-100 text-amber-700 rounded-xl">
              <HandCoins className="w-6 h-6" />
            </div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-emerald-200 shadow-xs bg-emerald-50/20">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-semibold text-emerald-700 uppercase tracking-wider">
                {isBn ? 'সমন্বিত / পরিশোধিত অগ্রিম' : 'Settled Advances'}
              </p>
              <h3 className="text-2xl font-bold text-emerald-700 mt-1">
                {currency} {totalRepaidOrDeducted.toLocaleString()}
              </h3>
              <p className="text-xs text-emerald-600 mt-1 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                {isBn ? 'নগদ বা বেতন শিটের মাধ্যমে পরিশোধিত' : 'Repaid or deducted'}
              </p>
            </div>
            <div className="p-3 bg-emerald-100 text-emerald-700 rounded-xl">
              <CheckCircle2 className="w-6 h-6" />
            </div>
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2">
        {(['all', 'unpaid', 'repaid', 'deducted'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setFilterStatus(tab)}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition cursor-pointer ${
              filterStatus === tab
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            {tab === 'all' && (isBn ? 'সবগুলো' : 'All')}
            {tab === 'unpaid' && (isBn ? 'বকেয়া (Unpaid)' : 'Unpaid')}
            {tab === 'repaid' && (isBn ? 'পরিশোধিত (Repaid)' : 'Repaid')}
            {tab === 'deducted' && (isBn ? 'বেতন থেকে কর্তিত' : 'Deducted')}
          </button>
        ))}
      </div>

      {/* List */}
      {filtered.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
          <HandCoins className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-700">
            {isBn ? 'কোনো অগ্রিম রেকর্ড পাওয়া যায়নি' : 'No advance records found'}
          </h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            {isBn
              ? 'কর্মচারীকে জরুরি ভিত্তিতে কোনো অগ্রিম টাকা দিলে তা এখানে এন্ট্রি রাখুন।'
              : 'Record employee salary advances to deduct during payroll.'}
          </p>
          <button
            onClick={onOpenAdvanceModal}
            className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold rounded-xl transition cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            {isBn ? '+ অগ্রিম এন্ট্রি করুন' : '+ Issue Advance'}
          </button>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-slate-500 text-xs uppercase font-semibold border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">{isBn ? 'কর্মচারী' : 'Employee'}</th>
                  <th className="py-3 px-4">{isBn ? 'টাকার পরিমাণ' : 'Amount'}</th>
                  <th className="py-3 px-4">{isBn ? 'তারিখ' : 'Date'}</th>
                  <th className="py-3 px-4">{isBn ? 'কারণ / বিবরণ' : 'Reason'}</th>
                  <th className="py-3 px-4">{isBn ? 'অবস্থা' : 'Status'}</th>
                  <th className="py-3 px-4 text-right">{isBn ? 'অ্যাকশন' : 'Action'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((adv) => (
                  <tr key={adv.id} className="hover:bg-slate-50/70 transition">
                    <td className="py-3.5 px-4 font-bold text-slate-900">
                      {adv.employeeName}
                    </td>

                    <td className="py-3.5 px-4 font-mono font-bold text-slate-900">
                      {currency} {adv.amount.toLocaleString()}
                    </td>

                    <td className="py-3.5 px-4 text-xs text-slate-600">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        {adv.date}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-xs text-slate-600 max-w-xs truncate">
                      {adv.reason || '-'}
                    </td>

                    <td className="py-3.5 px-4">
                      <select
                        value={adv.status}
                        onChange={(e) =>
                          onUpdateStatus(
                            adv,
                            e.target.value as 'unpaid' | 'repaid' | 'deducted'
                          )
                        }
                        className={`text-xs font-semibold rounded-lg px-2.5 py-1 border outline-none cursor-pointer ${
                          adv.status === 'unpaid'
                            ? 'bg-amber-50 text-amber-700 border-amber-300'
                            : adv.status === 'repaid'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                            : 'bg-blue-50 text-blue-700 border-blue-300'
                        }`}
                      >
                        <option value="unpaid">{isBn ? 'বকেয়া (Unpaid)' : 'Unpaid'}</option>
                        <option value="repaid">{isBn ? 'নগদে শোধ (Repaid)' : 'Repaid'}</option>
                        <option value="deducted">{isBn ? 'বেতনে কর্তিত' : 'Deducted'}</option>
                      </select>
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <button
                        onClick={() => handleDelete(adv.id, adv.employeeName, adv.amount)}
                        disabled={deletingId === adv.id}
                        className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer disabled:opacity-50"
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
