import React, { useState } from 'react';
import { ShieldCheck, Lock, LogIn, X, KeyRound, AlertCircle } from 'lucide-react';

interface MasterLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onGoogleLogin: () => Promise<void>;
  onPasscodeSuccess: () => void;
  isBn: boolean;
}

export const MasterLoginModal: React.FC<MasterLoginModalProps> = ({
  isOpen,
  onClose,
  onGoogleLogin,
  onPasscodeSuccess,
  isBn,
}) => {
  const [passcode, setPasscode] = useState('');
  const [error, setError] = useState('');
  const [loadingGoogle, setLoadingGoogle] = useState(false);

  if (!isOpen) return null;

  const validPasscodes = ['admin123', 'alamin2026', '123456', 'progress123'];

  const handlePasscodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validPasscodes.includes(passcode.trim())) {
      setError('');
      onPasscodeSuccess();
      onClose();
    } else {
      setError(
        isBn
          ? 'ভুল পাসকোড! সঠিক মাস্টার পাসকোড দিন (ডিফল্ট: admin123)'
          : 'Invalid passcode! Please enter correct master passcode (default: admin123)'
      );
    }
  };

  const handleGoogleClick = async () => {
    setLoadingGoogle(true);
    setError('');
    try {
      await onGoogleLogin();
      onClose();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'লগইন ব্যর্থ হয়েছে');
    } finally {
      setLoadingGoogle(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 border border-slate-200 relative animate-in fade-in zoom-in duration-150">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-6">
          <div className="w-12 h-12 bg-amber-50 border border-amber-200 rounded-2xl flex items-center justify-center mx-auto mb-3 text-amber-700 shadow-xs">
            <Lock className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-slate-900">
            {isBn ? 'মাস্টার ইউজার কন্ট্রোল লগইন' : 'Master User Control Login'}
          </h3>
          <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
            {isBn
              ? 'ডাটা আপলোড, পরিবর্তন (Modify) বা ডিলিট করার জন্য মাস্টার এক্সেস প্রয়োজন। সাধারণ কর্মচারীরা শুধু ভিউ করতে পারবেন।'
              : 'Master access is required to upload, modify, or delete data. Other employees have view-only access.'}
          </p>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Option 1: Quick Master Passcode */}
        <form onSubmit={handlePasscodeSubmit} className="space-y-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              {isBn ? 'মাস্টার পাসকোড (Master Passcode)' : 'Master Passcode'}
            </label>
            <div className="relative">
              <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                value={passcode}
                onChange={(e) => setPasscode(e.target.value)}
                placeholder="admin123"
                className="w-full pl-9 pr-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none transition"
                autoFocus
              />
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              {isBn ? 'মাস্টার ডিফল্ট কোড: admin123' : 'Master default code: admin123'}
            </p>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 px-4 bg-slate-900 hover:bg-slate-800 text-amber-400 font-bold text-xs rounded-xl shadow-xs transition flex items-center justify-center gap-2 cursor-pointer"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>{isBn ? 'মাস্টার মোড চালু করুন' : 'Unlock Master Mode'}</span>
          </button>
        </form>

        <div className="my-4 flex items-center gap-3">
          <div className="flex-1 h-px bg-slate-200"></div>
          <span className="text-[11px] text-slate-400 uppercase font-medium">
            {isBn ? 'অথবা' : 'OR'}
          </span>
          <div className="flex-1 h-px bg-slate-200"></div>
        </div>

        {/* Option 2: Google Sign In */}
        <button
          type="button"
          onClick={handleGoogleClick}
          disabled={loadingGoogle}
          className="w-full py-2 px-4 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 font-semibold text-xs rounded-xl transition flex items-center justify-center gap-2 cursor-pointer"
        >
          <LogIn className="w-4 h-4 text-rose-600" />
          <span>
            {loadingGoogle
              ? (isBn ? 'লগইন হচ্ছে...' : 'Signing in...')
              : (isBn ? 'গুগল দিয়ে মাস্টার সাইন-ইন' : 'Sign in with Google Account')}
          </span>
        </button>
      </div>
    </div>
  );
};
