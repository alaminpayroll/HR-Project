import React, { useState } from 'react';
import {
  Users,
  UserPlus,
  Search,
  Edit2,
  Trash2,
  Phone,
  Briefcase,
  CheckCircle2,
  Building,
  CreditCard,
  UserSearch,
} from 'lucide-react';
import type { Employee } from '../types';

interface EmployeesViewProps {
  employees: Employee[];
  currency: string;
  isBn: boolean;
  onAddEmployee: () => void;
  onEditEmployee: (employee: Employee) => void;
  onDeleteEmployee: (employeeId: string) => Promise<void>;
  onViewPortal?: (empId: string) => void;
}

export const EmployeesView: React.FC<EmployeesViewProps> = ({
  employees,
  currency,
  isBn,
  onAddEmployee,
  onEditEmployee,
  onDeleteEmployee,
  onViewPortal,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'inactive'>('all');
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const filteredEmployees = employees.filter((emp) => {
    const matchesSearch =
      emp.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      emp.phone.includes(searchTerm) ||
      emp.designation.toLowerCase().includes(searchTerm.toLowerCase()) ||
      emp.department.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus =
      filterStatus === 'all' ? true : emp.status === filterStatus;

    return matchesSearch && matchesStatus;
  });

  const handleDelete = async (id: string, name: string) => {
    const confirmText = isBn
      ? `আপনি কি নিশ্চিত '${name}' এর সমস্ত রেকর্ড মুছে ফেলতে চান?`
      : `Are you sure you want to delete employee '${name}'?`;

    if (window.confirm(confirmText)) {
      setDeletingId(id);
      try {
        await onDeleteEmployee(id);
      } finally {
        setDeletingId(null);
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Filter Controls */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <Users className="w-5 h-5 text-blue-600" />
            {isBn ? 'কর্মচারী ব্যবস্থাপনা ও প্রোফাইল' : 'Employee Directory'}
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {isBn
              ? 'কর্মচারীদের তথ্য স্বয়ংক্রিয়ভাবে ক্লাউড ডাটাবেজে সেভ থাকবে'
              : 'All staff records are synced to Cloud Firestore in real time'}
          </p>
        </div>

        <button
          onClick={onAddEmployee}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm rounded-xl shadow-xs transition cursor-pointer"
        >
          <UserPlus className="w-4 h-4" />
          {isBn ? '+ নতুন কর্মচারী যুক্ত করুন' : '+ Add New Employee'}
        </button>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={
              isBn
                ? 'নাম, মোবাইল নম্বর, পদবী বা বিভাগ দিয়ে সার্চ করুন...'
                : 'Search by name, phone, role, or department...'
            }
            className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition"
          />
        </div>

        <div className="flex gap-2">
          <select
            value={filterStatus}
            onChange={(e) =>
              setFilterStatus(e.target.value as 'all' | 'active' | 'inactive')
            }
            className="px-3.5 py-2.5 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition cursor-pointer"
          >
            <option value="all">{isBn ? 'সব স্ট্যাটাস' : 'All Status'}</option>
            <option value="active">{isBn ? 'শুধু সক্রিয় (Active)' : 'Active Only'}</option>
            <option value="inactive">{isBn ? 'শুধু নিষ্ক্রিয় (Inactive)' : 'Inactive Only'}</option>
          </select>
        </div>
      </div>

      {/* Employee List */}
      {filteredEmployees.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
          <Users className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-700">
            {isBn ? 'কোনো কর্মচারী পাওয়া যায়নি' : 'No employees found'}
          </h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            {searchTerm
              ? isBn
                ? 'আপনার সার্চ অনুযায়ী কোনো রেকর্ড পাওয়া যায়নি।'
                : 'No employee records matching your query.'
              : isBn
              ? 'আপনার প্রতিষ্ঠানের কর্মচারীদের ডাটাবেজে অন্তর্ভুক্ত করতে উপরের বাটনে ক্লিক করুন।'
              : 'Add your first employee to start payroll management.'}
          </p>
          <button
            onClick={onAddEmployee}
            className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-xl transition cursor-pointer"
          >
            <UserPlus className="w-3.5 h-3.5" />
            {isBn ? '+ কর্মচারী যোগ করুন' : '+ Add Employee'}
          </button>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-slate-500 text-xs uppercase font-semibold border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">{isBn ? 'কর্মচারী' : 'Employee'}</th>
                  <th className="py-3 px-4">{isBn ? 'যোগাযোগ' : 'Contact'}</th>
                  <th className="py-3 px-4">{isBn ? 'পদবী ও শাখা' : 'Role & Dept'}</th>
                  <th className="py-3 px-4">{isBn ? 'বেতন' : 'Salary'}</th>
                  <th className="py-3 px-4">{isBn ? 'পেমেন্ট ইনফো' : 'Payment'}</th>
                  <th className="py-3 px-4">{isBn ? 'অবস্থা' : 'Status'}</th>
                  <th className="py-3 px-4 text-right">{isBn ? 'অ্যাকশন' : 'Actions'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredEmployees.map((emp) => (
                  <tr key={emp.id} className="hover:bg-slate-50/70 transition">
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-slate-900">{emp.name}</span>
                        {emp.employeeCode && (
                          <span className="px-1.5 py-0.5 text-[10px] font-mono font-bold bg-slate-100 text-slate-700 rounded border border-slate-200">
                            {emp.employeeCode}
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-slate-400">
                        {isBn ? 'যোগদান: ' : 'Joined: '}
                        {emp.joiningDate || 'N/A'}
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      {emp.phone ? (
                        <div className="flex items-center gap-1.5 text-xs text-slate-700 font-medium">
                          <Phone className="w-3.5 h-3.5 text-slate-400" />
                          <span>{emp.phone}</span>
                        </div>
                      ) : (
                        <span className="text-xs text-slate-400">-</span>
                      )}
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="text-xs font-semibold text-slate-800 flex items-center gap-1">
                        <Briefcase className="w-3.5 h-3.5 text-slate-400" />
                        <span>{emp.designation}</span>
                      </div>
                      <div className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                        <Building className="w-3 h-3 text-slate-400" />
                        <span>{emp.department}</span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900 text-sm">
                        {currency} {emp.monthlySalary.toLocaleString()}
                      </div>
                      <span className="text-xs text-slate-500 capitalize">
                        {emp.salaryType === 'monthly'
                          ? isBn
                            ? 'মাসিক'
                            : 'Monthly'
                          : isBn
                          ? 'দৈনিক মজুরি'
                          : 'Daily Wage'}
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="inline-flex items-center gap-1 text-xs font-medium text-slate-700 capitalize">
                        <CreditCard className="w-3.5 h-3.5 text-slate-400" />
                        <span>{emp.paymentMethod}</span>
                      </div>
                      {emp.accountDetails && (
                        <p className="text-[11px] text-slate-500 truncate max-w-[150px]">
                          {emp.accountDetails}
                        </p>
                      )}
                    </td>

                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-full ${
                          emp.status === 'active'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-slate-100 text-slate-600 border border-slate-200'
                        }`}
                      >
                        {emp.status === 'active' && <CheckCircle2 className="w-3 h-3" />}
                        {emp.status === 'active'
                          ? isBn
                            ? 'সক্রিয়'
                            : 'Active'
                          : isBn
                          ? 'নিষ্ক্রিয়'
                          : 'Inactive'}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {onViewPortal && (
                          <button
                            onClick={() => onViewPortal(emp.id)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition cursor-pointer"
                            title="ছুটির পোর্টাল দেখুন"
                          >
                            <UserSearch className="w-3.5 h-3.5" />
                            <span>{isBn ? 'ছুটি পোর্টাল' : 'Portal'}</span>
                          </button>
                        )}
                        <button
                          onClick={() => onEditEmployee(emp)}
                          className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition cursor-pointer"
                          title="Edit"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(emp.id, emp.name)}
                          disabled={deletingId === emp.id}
                          className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer disabled:opacity-50"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="p-3 bg-slate-50 border-t border-slate-200 text-xs text-slate-500 flex justify-between">
            <span>
              {isBn ? 'মোট ফিল্টারকৃত কর্মচারী:' : 'Filtered Employees:'}{' '}
              {filteredEmployees.length} {isBn ? 'জন' : ''}
            </span>
            <span className="text-emerald-700 font-medium">
              ✓ {isBn ? 'সব পরিবর্তন ক্লাউডে সংরক্ষিত' : 'Changes saved to Cloud'}
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
