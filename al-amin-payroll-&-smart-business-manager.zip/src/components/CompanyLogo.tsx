import React from 'react';

interface CompanyLogoProps {
  className?: string;
  size?: number;
}

export const CompanyLogo: React.FC<CompanyLogoProps> = ({
  className = 'w-10 h-10',
  size = 48,
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 500 500"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`shrink-0 drop-shadow-md ${className}`}
    >
      <defs>
        {/* Deep Crimson Circular Gradient */}
        <radialGradient
          id="crimsonGrad"
          cx="38%"
          cy="35%"
          r="65%"
          fx="35%"
          fy="30%"
        >
          <stop offset="0%" stopColor="#A82028" />
          <stop offset="70%" stopColor="#8E1820" />
          <stop offset="100%" stopColor="#6B1016" />
        </radialGradient>

        {/* Metallic Bevel Gradient for 3D Left Stem */}
        <linearGradient id="silverStem" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="40%" stopColor="#D4D4D8" />
          <stop offset="75%" stopColor="#71717A" />
          <stop offset="100%" stopColor="#3F3F46" />
        </linearGradient>

        {/* Dark Metallic Shadow Gradient */}
        <linearGradient id="metalShadow" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#52525B" />
          <stop offset="100%" stopColor="#27272A" />
        </linearGradient>

        {/* Drop Shadow for the 3D Monogram */}
        <filter id="logoShadow" x="-10%" y="-10%" width="130%" height="130%">
          <feDropShadow dx="3" dy="5" stdDeviation="4" floodColor="#000000" floodOpacity="0.45" />
        </filter>
      </defs>

      {/* Outer Crimson Circle */}
      <circle cx="250" cy="250" r="236" fill="url(#crimsonGrad)" />

      {/* Inner Monogram Group */}
      <g filter="url(#logoShadow)">
        {/* 3D Drop / Depth Shadow Edge for P-Loop */}
        <path
          d="M 105 76 
             C 210 52, 335 60, 368 155 
             C 392 225, 345 285, 275 292 
             L 170 292 
             L 170 310 
             L 275 310 
             C 360 305, 410 230, 385 145 
             C 345 40, 205 32, 90 60 
             Z"
          fill="#3F3F46"
          opacity="0.8"
        />

        {/* Main White Ribbon of "P" loop */}
        <path
          d="M 98 70 
             C 205 48, 330 55, 362 148 
             C 385 215, 340 274, 272 280 
             L 142 280 
             L 142 254 
             L 268 254 
             C 320 250, 355 205, 336 152 
             C 312 85, 205 74, 110 94 
             Z"
          fill="#FFFFFF"
        />

        {/* Vertical Left Stem of "P" - 3D Beveled Face */}
        <polygon
          points="120,205 142,205 142,442 120,442"
          fill="url(#silverStem)"
        />
        {/* Left Side Shadow of the Vertical Stem */}
        <polygon
          points="102,205 120,205 120,442 102,442"
          fill="url(#metalShadow)"
        />

        {/* The "A" Chevron Roof & Right Diagonal Leg */}
        {/* 3D Depth Shadow on Right Leg */}
        <polygon
          points="285,250 418,416 398,432 270,270"
          fill="#27272A"
          opacity="0.75"
        />
        {/* Left ascending diagonal of "A" connecting from bottom left */}
        <polygon
          points="120,442 142,442 285,250 268,235"
          fill="url(#silverStem)"
        />
        {/* Right descending diagonal of "A" */}
        <polygon
          points="285,250 298,266 418,416 398,416"
          fill="#FFFFFF"
        />
        {/* Inner Peak Highlight */}
        <path
          d="M 285 250 L 268 272 L 312 328 L 328 312 Z"
          fill="#E4E4E7"
        />
      </g>
    </svg>
  );
};
