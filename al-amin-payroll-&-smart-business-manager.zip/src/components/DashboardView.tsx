import React from 'react';
import {
  Users,
  Banknote,
  CalendarCheck,
  HandCoins,
  UserPlus,
  Receipt,
  CheckCircle2,
  AlertCircle,
  Database,
  ArrowRight,
  TrendingUp,
  Clock,
  UserSearch,
} from 'lucide-react';
import type { Employee, AttendanceRecord, PayrollRecord, AdvanceLoan } from '../types';

interface DashboardViewProps {
  employees: Employee[];
  attendance: AttendanceRecord[];
  payrolls: PayrollRecord[];
  advances: AdvanceLoan[];
  currency: string;
  isBn: boolean;
  onNavigate: (tab: string) => void;
  onOpenEmployeeModal: () => void;
  onOpenAdvanceModal: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  employees,
  attendance,
  payrolls,
  advances,
  currency,
  isBn,
  onNavigate,
  onOpenEmployeeModal,
  onOpenAdvanceModal,
}) => {
  const activeEmployees = employees.filter((e) => e.status === 'active');
  const totalBudget = activeEmployees.reduce((acc, curr) => acc + (curr.monthlySalary || 0), 0);
  const unpaidAdvances = advances
    .filter((a) => a.status === 'unpaid')
    .reduce((acc, curr) => acc + (curr.amount || 0), 0);

  const todayStr = new Date().toISOString().split('T')[0];
  const todayRecords = attendance.filter((a) => a.date === todayStr);
  const presentCount = todayRecords.filter(
    (a) => a.status === 'present' || a.status === 'late' || a.status === 'half_day'
  ).length;
  const absentCount = todayRecords.filter((a) => a.status === 'absent').length;

  return (
    <div className="space-y-6">
      {/* Cloud Persistence Guarantee Banner */}
      <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-900 rounded-2xl p-6 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-xs font-semibold mb-3">
            <Database className="w-3.5 h-3.5 text-emerald-300 animate-pulse" />
            <span>{isBn ? 'ক্লাউড ডাটাবেজ সক্রিয়' : 'Persistent Cloud Storage Active'}</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight">
            {isBn
              ? 'আপনার প্রতিটি ডাটা স্থায়ীভাবে ক্লাউডে সংরক্ষিত হচ্ছে'
              : 'Your data is continuously saved & persisted in the Cloud'}
          </h2>
          <p className="mt-2 text-sm text-blue-100 leading-relaxed">
            {isBn
              ? 'ব্রাউজার রিফ্রেশ করলে, ক্যাশ ডিলিট করলে বা নতুন কোনো মোবাইল/কম্পিউটার থেকে লিংকটি ওপেন করলেও কোনো তথ্য মুছে যাবে না।'
              : 'Never worry about lost data. All employee records, daily attendance, advances, and payroll sheets are securely kept in Google Firebase Firestore.'}
          </p>
          <div className="mt-5 flex flex-wrap gap-3">
            <button
              onClick={() => onNavigate('portal')}
              className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs sm:text-sm rounded-xl transition shadow-xs cursor-pointer"
            >
              <UserSearch className="w-4 h-4" />
              {isBn ? 'ইমপ্লয়ী পোর্টাল ও ছুটির হিসাব' : 'Employee Portal & Leave'}
            </button>
            <button
              onClick={onOpenEmployeeModal}
              className="inline-flex items-center gap-2 px-4 py-2 bg-white text-blue-800 font-bold text-xs sm:text-sm rounded-xl hover:bg-blue-50 transition shadow-xs cursor-pointer"
            >
              <UserPlus className="w-4 h-4 text-blue-600" />
              {isBn ? '+ কর্মচারী যোগ করুন' : '+ Add Employee'}
            </button>
            <button
              onClick={() => onNavigate('attendance')}
              className="inline-flex items-center gap-2 px-4 py-2 bg-blue-500/30 hover:bg-blue-500/40 text-white font-semibold text-xs sm:text-sm rounded-xl border border-white/20 transition cursor-pointer"
            >
              <CalendarCheck className="w-4 h-4" />
              {isBn ? 'আজকের হাজিরা দিন' : 'Mark Attendance'}
            </button>
            <button
              onClick={() => onNavigate('payroll')}
              className="inline-flex items-center gap-2 px-4 py-2 bg-blue-500/30 hover:bg-blue-500/40 text-white font-semibold text-xs sm:text-sm rounded-xl border border-white/20 transition cursor-pointer"
            >
              <Receipt className="w-4 h-4" />
              {isBn ? 'বেতন শিট প্রসেস' : 'Process Payroll'}
            </button>
          </div>
        </div>
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Employees */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-blue-300 transition">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                {isBn ? 'মোট কর্মচারী' : 'Total Employees'}
              </p>
              <h3 className="text-2xl font-bold text-slate-900 mt-1">
                {employees.length} <span className="text-sm font-normal text-slate-500">{isBn ? 'জন' : ''}</span>
              </h3>
              <p className="text-xs text-emerald-600 font-medium mt-1 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                {activeEmployees.length} {isBn ? 'জন সক্রিয় স্টাফ' : 'Active Staff'}
              </p>
            </div>
            <div className="p-3 bg-blue-50 text-blue-600 rounded-xl">
              <Users className="w-5 h-5" />
            </div>
          </div>
        </div>

        {/* Monthly Payroll Obligation */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-emerald-300 transition">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                {isBn ? 'মাসিক বেতন বাজেট' : 'Monthly Salary Budget'}
              </p>
              <h3 className="text-2xl font-bold text-slate-900 mt-1">
                {currency} {totalBudget.toLocaleString()}
              </h3>
              <p className="text-xs text-slate-500 mt-1 flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5 text-blue-500" />
                {isBn ? 'সক্রিয় কর্মচারীদের মোট বেতন' : 'Base for active staff'}
              </p>
            </div>
            <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
              <Banknote className="w-5 h-5" />
            </div>
          </div>
        </div>

        {/* Today's Attendance */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-indigo-300 transition">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                {isBn ? 'আজকের উপস্থিতি' : "Today's Attendance"}
              </p>
              <h3 className="text-2xl font-bold text-slate-900 mt-1">
                {presentCount} / {activeEmployees.length || 0}
              </h3>
              <p className="text-xs text-slate-500 mt-1 flex items-center gap-1.5">
                <span className="inline-block w-2 h-2 rounded-full bg-emerald-500"></span>
                <span>{presentCount} {isBn ? 'উপস্থিত' : 'Present'}</span>
                <span className="inline-block w-2 h-2 rounded-full bg-rose-500 ml-1"></span>
                <span>{absentCount} {isBn ? 'অনুপস্থিত' : 'Absent'}</span>
              </p>
            </div>
            <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl">
              <CalendarCheck className="w-5 h-5" />
            </div>
          </div>
        </div>

        {/* Outstanding Advances */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-amber-300 transition">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                {isBn ? 'বকেয়া অগ্রিম ঋণ' : 'Outstanding Advances'}
              </p>
              <h3 className="text-2xl font-bold text-amber-600 mt-1">
                {currency} {unpaidAdvances.toLocaleString()}
              </h3>
              <p className="text-xs text-slate-500 mt-1 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-amber-500" />
                {isBn ? 'বেতন থেকে সমন্বয়ের অপেক্ষায়' : 'Awaiting salary deduction'}
              </p>
            </div>
            <div className="p-3 bg-amber-50 text-amber-600 rounded-xl">
              <HandCoins className="w-5 h-5" />
            </div>
          </div>
        </div>
      </div>

      {/* Split Section: Quick Actions & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Quick Action Hub */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs">
          <h3 className="font-bold text-base text-slate-900 mb-4 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-blue-600"></span>
            {isBn ? 'দ্রুত কাজের মেনু' : 'Quick Actions'}
          </h3>
          <div className="space-y-2.5">
            <button
              onClick={() => onNavigate('portal')}
              className="w-full flex items-center justify-between p-3.5 rounded-xl border border-emerald-200 bg-emerald-50/40 hover:border-emerald-400 hover:bg-emerald-50 transition group cursor-pointer text-left"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-emerald-100 text-emerald-700 group-hover:bg-emerald-600 group-hover:text-white transition">
                  <UserSearch className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-slate-800">
                    {isBn ? 'ইমপ্লয়ী পোর্টাল ও ছুটির হিসাব' : 'Employee Portal & Leave'}
                  </h4>
                  <p className="text-xs text-slate-500">
                    {isBn ? 'ID সার্চ, চাকরির মেয়াদ ও ছুটির ব্যালেন্স' : 'ID search, service length & leave balance'}
                  </p>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-emerald-600 transition" />
            </button>

            <button
              onClick={onOpenEmployeeModal}
              className="w-full flex items-center justify-between p-3.5 rounded-xl border border-slate-200 hover:border-blue-400 hover:bg-blue-50/50 transition group cursor-pointer text-left"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-blue-50 text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition">
                  <UserPlus className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-slate-800">
                    {isBn ? 'নতুন কর্মচারী নিবন্ধন' : 'Add Employee'}
                  </h4>
                  <p className="text-xs text-slate-500">
                    {isBn ? 'নাম, পদবী ও মাসিক বেতন নির্ধারণ' : 'Register staff profile'}
                  </p>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 transition" />
            </button>

            <button
              onClick={() => onNavigate('attendance')}
              className="w-full flex items-center justify-between p-3.5 rounded-xl border border-slate-200 hover:border-indigo-400 hover:bg-indigo-50/50 transition group cursor-pointer text-left"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600 group-hover:bg-indigo-600 group-hover:text-white transition">
                  <CalendarCheck className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-slate-800">
                    {isBn ? 'দৈনিক হাজিরা ও ওভারটাইম' : 'Daily Attendance'}
                  </h4>
                  <p className="text-xs text-slate-500">
                    {isBn ? '১-ক্লিকে সবার উপস্থিতি মার্ক করুন' : 'Mark daily presence & overtime'}
                  </p>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 transition" />
            </button>

            <button
              onClick={() => onNavigate('payroll')}
              className="w-full flex items-center justify-between p-3.5 rounded-xl border border-slate-200 hover:border-emerald-400 hover:bg-emerald-50/50 transition group cursor-pointer text-left"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white transition">
                  <Receipt className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-slate-800">
                    {isBn ? 'মাসিক বেতন হিসাব ও স্লিপ' : 'Payroll Sheet & Slips'}
                  </h4>
                  <p className="text-xs text-slate-500">
                    {isBn ? 'স্বয়ংক্রিয় বেতন ও কর্তন হিসাব' : 'Compute salary & generate slips'}
                  </p>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-600 transition" />
            </button>

            <button
              onClick={onOpenAdvanceModal}
              className="w-full flex items-center justify-between p-3.5 rounded-xl border border-slate-200 hover:border-amber-400 hover:bg-amber-50/50 transition group cursor-pointer text-left"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-amber-50 text-amber-600 group-hover:bg-amber-600 group-hover:text-white transition">
                  <HandCoins className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-slate-800">
                    {isBn ? 'অগ্রিম বেতন / লোন প্রদান' : 'Issue Advance Loan'}
                  </h4>
                  <p className="text-xs text-slate-500">
                    {isBn ? 'কর্মচারীকে অগ্রিম টাকা এন্ট্রি করুন' : 'Record employee advance loan'}
                  </p>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-amber-600 transition" />
            </button>
          </div>
        </div>

        {/* Staff Quick Overview */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
                <Users className="w-4 h-4 text-blue-600" />
                {isBn ? 'কর্মচারী বিবরণ ও বেতন তালিকা' : 'Employee Overview'}
              </h3>
              <button
                onClick={() => onNavigate('employees')}
                className="text-xs font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1 cursor-pointer"
              >
                {isBn ? 'সবগুলো দেখুন' : 'View All'}
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {employees.length === 0 ? (
              <div className="text-center py-10 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                <Users className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <p className="text-sm font-medium text-slate-600">
                  {isBn ? 'কোনো কর্মচারী যোগ করা হয়নি' : 'No employees added yet'}
                </p>
                <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                  {isBn
                    ? 'স্থায়ীভাবে ডাটা সেভ পরীক্ষা করার জন্য নিচে "+ কর্মচারী যোগ করুন" বাটনে ক্লিক করুন।'
                    : 'Click below to register your first employee profile.'}
                </p>
                <button
                  onClick={onOpenEmployeeModal}
                  className="mt-4 px-4 py-2 bg-blue-600 text-white text-xs font-semibold rounded-xl hover:bg-blue-700 transition cursor-pointer"
                >
                  {isBn ? '+ প্রথম কর্মচারী যুক্ত করুন' : '+ Add First Employee'}
                </button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-50 text-slate-500 text-xs uppercase font-semibold">
                    <tr>
                      <th className="py-2.5 px-3 rounded-l-lg">{isBn ? 'নাম' : 'Name'}</th>
                      <th className="py-2.5 px-3">{isBn ? 'পদবী' : 'Role'}</th>
                      <th className="py-2.5 px-3">{isBn ? 'মূল বেতন' : 'Salary'}</th>
                      <th className="py-2.5 px-3">{isBn ? 'পেমেন্ট মাধ্যম' : 'Payment'}</th>
                      <th className="py-2.5 px-3 rounded-r-lg">{isBn ? 'অবস্থা' : 'Status'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {employees.slice(0, 5).map((emp) => (
                      <tr key={emp.id} className="hover:bg-slate-50/80 transition">
                        <td className="py-2.5 px-3 font-semibold text-slate-800">
                          {emp.name}
                        </td>
                        <td className="py-2.5 px-3 text-slate-600 text-xs">
                          {emp.designation}
                        </td>
                        <td className="py-2.5 px-3 font-mono font-medium text-slate-900 text-xs">
                          {currency} {emp.monthlySalary.toLocaleString()}
                        </td>
                        <td className="py-2.5 px-3 text-xs text-slate-500 capitalize">
                          {emp.paymentMethod}
                        </td>
                        <td className="py-2.5 px-3">
                          <span
                            className={`inline-block px-2 py-0.5 text-xs font-semibold rounded-full ${
                              emp.status === 'active'
                                ? 'bg-emerald-50 text-emerald-700'
                                : 'bg-slate-100 text-slate-500'
                            }`}
                          >
                            {emp.status === 'active' ? (isBn ? 'সক্রিয়' : 'Active') : (isBn ? 'নিষ্ক্রিয়' : 'Inactive')}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              {isBn ? 'সব এন্ট্রি ক্লাউড ডাটাবেজে লাইভ সিনক্রোনাইজড' : 'Live synchronized to Cloud DB'}
            </span>
            <span>{employees.length} {isBn ? 'জন কর্মচারী নিবন্ধিত' : 'registered'}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
