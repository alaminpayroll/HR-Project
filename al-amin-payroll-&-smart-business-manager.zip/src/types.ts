export interface Employee {
  id: string;
  userId: string;
  employeeCode: string; // e.g. EMP-001
  name: string;
  phone: string;
  designation: string;
  department: string;
  monthlySalary: number;
  salaryType: 'monthly' | 'daily';
  joiningDate: string; // DOJ
  status: 'active' | 'inactive';
  paymentMethod: 'cash' | 'bKash' | 'Nagad' | 'bank';
  accountDetails: string;
  createdAt: string;
  updatedAt: string;
}

export interface AttendanceRecord {
  id: string;
  userId: string;
  employeeId: string;
  employeeName: string;
  date: string; // YYYY-MM-DD
  status: 'present' | 'absent' | 'late' | 'half_day' | 'leave';
  overtimeHours: number;
  note?: string;
  createdAt: string;
}

export interface EmployeeLeave {
  id: string;
  userId: string;
  employeeId: string;
  employeeCode: string; // e.g. EMP-001
  employeeName: string;
  department: string;
  designation: string;
  doj: string; // Date of Joining
  year: number; // e.g. 2026
  casualAllocated: number;
  casualAvailed: number;
  casualBalance: number;
  sickAllocated: number;
  sickAvailed: number;
  sickBalance: number;
  earnAllocated: number;
  earnAvailed: number;
  earnBalance: number;
  specialAllocated: number;
  specialAvailed: number;
  specialBalance: number;
  lwpAvailed: number;
  updatedAt: string;
}

export interface PayrollRecord {
  id: string;
  userId: string;
  employeeId: string;
  employeeName: string;
  monthYear: string; // e.g. "2026-10"
  baseSalary: number;
  presentDays: number;
  absentDays: number;
  overtimePay: number;
  bonus: number;
  advanceDeduction: number;
  otherDeductions: number;
  netPayable: number;
  paymentStatus: 'paid' | 'partial' | 'pending';
  paidAmount: number;
  paymentMethod: 'cash' | 'bKash' | 'Nagad' | 'bank';
  paymentDate: string;
  notes?: string;
  createdAt: string;
}

export interface AdvanceLoan {
  id: string;
  userId: string;
  employeeId: string;
  employeeName: string;
  amount: number;
  date: string;
  reason: string;
  status: 'unpaid' | 'repaid' | 'deducted';
  createdAt: string;
}

export interface CompanySetting {
  id: string;
  userId: string;
  companyName: string;
  ownerEmail?: string;
  phone?: string;
  currency: string;
  workingDaysPerMonth: number;
  overtimeRatePerHour: number;
  language: 'bn' | 'en';
  updatedAt: string;
}
