import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  onSnapshot,
  getDoc,
  writeBatch,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import type {
  Employee,
  AttendanceRecord,
  PayrollRecord,
  AdvanceLoan,
  CompanySetting,
  EmployeeLeave,
} from '../types';

// Helper to generate clean IDs compliant with isValidId (alphanumeric and dashes, <= 128)
export function generateCleanId(prefix = 'doc'): string {
  const rand = Math.random().toString(36).substring(2, 10);
  const time = Date.now().toString(36);
  return `${prefix}-${time}-${rand}`;
}

// ---------------- Employees (Realtime for all Viewers & Master) ----------------
export function subscribeEmployees(
  _userId: string,
  onSuccess: (employees: Employee[]) => void,
  onError?: (err: Error) => void
) {
  const collectionPath = 'employees';
  const colRef = collection(db, collectionPath);

  return onSnapshot(
    colRef,
    (snapshot) => {
      const list: Employee[] = [];
      snapshot.forEach((docSnap) => {
        list.push({ ...(docSnap.data() as Employee), id: docSnap.id });
      });
      // Sort by employeeCode or name
      list.sort((a, b) => (a.employeeCode || a.id).localeCompare(b.employeeCode || b.id));
      onSuccess(list);
    },
    (error) => {
      if (onError) onError(error as Error);
      handleFirestoreError(error, OperationType.LIST, collectionPath);
    }
  );
}

export async function saveEmployee(employee: Employee): Promise<void> {
  const collectionPath = 'employees';
  const docRef = doc(db, collectionPath, employee.id);
  try {
    await setDoc(docRef, employee, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${collectionPath}/${employee.id}`);
  }
}

export async function deleteEmployeeRecord(employeeId: string): Promise<void> {
  const collectionPath = 'employees';
  const docRef = doc(db, collectionPath, employeeId);
  try {
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `${collectionPath}/${employeeId}`);
  }
}

// ---------------- Employee Leave Ledger (Realtime for all Viewers & Master) ----------------
export function subscribeEmployeeLeaves(
  _userId: string,
  onSuccess: (leaves: EmployeeLeave[]) => void,
  onError?: (err: Error) => void
) {
  const collectionPath = 'leaves';
  const colRef = collection(db, collectionPath);

  return onSnapshot(
    colRef,
    (snapshot) => {
      const list: EmployeeLeave[] = [];
      snapshot.forEach((docSnap) => {
        list.push({ ...(docSnap.data() as EmployeeLeave), id: docSnap.id });
      });
      onSuccess(list);
    },
    (error) => {
      if (onError) onError(error as Error);
      handleFirestoreError(error, OperationType.LIST, collectionPath);
    }
  );
}

export async function saveEmployeeLeave(leave: EmployeeLeave): Promise<void> {
  const collectionPath = 'leaves';
  const docRef = doc(db, collectionPath, leave.id);
  try {
    await setDoc(docRef, leave, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${collectionPath}/${leave.id}`);
  }
}

export async function bulkSaveEmployeeLeaves(leaves: EmployeeLeave[]): Promise<void> {
  if (leaves.length === 0) return;
  const collectionPath = 'leaves';
  try {
    const batch = writeBatch(db);
    for (const leave of leaves) {
      const docRef = doc(db, collectionPath, leave.id);
      batch.set(docRef, leave, { merge: true });
    }
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, collectionPath);
  }
}

export async function deleteEmployeeLeave(leaveId: string): Promise<void> {
  const collectionPath = 'leaves';
  const docRef = doc(db, collectionPath, leaveId);
  try {
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `${collectionPath}/${leaveId}`);
  }
}

// ---------------- Company Settings ----------------
export async function getCompanySettings(_userId: string): Promise<CompanySetting | null> {
  const collectionPath = 'settings';
  const docRef = doc(db, collectionPath, 'default');
  try {
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      return snap.data() as CompanySetting;
    }
    return null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `${collectionPath}/default`);
  }
}

export async function saveCompanySettings(settings: CompanySetting): Promise<void> {
  const collectionPath = 'settings';
  const docRef = doc(db, collectionPath, 'default');
  try {
    await setDoc(docRef, { ...settings, id: 'default' }, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${collectionPath}/default`);
  }
}
