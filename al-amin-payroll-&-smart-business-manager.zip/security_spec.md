# Security Specification: Payroll & Data Persistence App

## 1. Data Invariants
- Every document must strictly belong to the authenticated owner (`userId == request.auth.uid`).
- Unauthenticated access and cross-tenant reads or writes are strictly forbidden.
- Client cannot fabricate or modify another user's `userId`.
- String lengths and payload boundaries are strictly enforced to prevent Denial of Wallet attacks.
- Only authenticated users with verified email (`request.auth.token.email_verified == true` or valid `request.auth != null`) can execute mutations.

## 2. The Dirty Dozen Payloads (Targeting Rejection)
1. Cross-Tenant Hijack: Write employee document where `userId != request.auth.uid`. -> PERMISSION_DENIED
2. Blanket Query Exfiltration: Client lists documents without filtering `userId == request.auth.uid`. -> PERMISSION_DENIED
3. Oversized Payload Injection: Name field length > 100 characters. -> PERMISSION_DENIED
4. Negative Salary Vulnerability: Setting `monthlySalary` to a negative number or NaN. -> PERMISSION_DENIED
5. Unauthorized ID Poisoning: Path variable documentId exceeding 128 characters or containing illegal punctuation. -> PERMISSION_DENIED
6. Shadow Field Injection: Adding `isAdmin: true` or rogue property during employee creation. -> PERMISSION_DENIED
7. Immutable Field Mutation: Attempting to change `userId` during an update. -> PERMISSION_DENIED
8. Attendance Spoofing: Submitting attendance for an employee under a different tenant's account. -> PERMISSION_DENIED
9. Non-numeric Financial Injection: Providing text in `netPayable` or `advanceDeduction`. -> PERMISSION_DENIED
10. Unauthenticated Access: Read or write when `request.auth == null`. -> PERMISSION_DENIED
11. Status Step Skip / Invalid Enum: Setting status to an undefined state like `"hacked"`. -> PERMISSION_DENIED
12. Orphaned Write Attack: Writing into a non-declared collection. -> PERMISSION_DENIED
